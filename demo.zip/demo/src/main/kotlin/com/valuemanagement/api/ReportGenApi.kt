package com.valuemanagement.api


import com.sun.org.apache.bcel.internal.generic.GOTO
import com.valuemanagement.model.*
import com.valuemanagement.state.CreateServiceCreditState
import com.valuemanagement.state.ValueContractTransactionState
import net.corda.core.messaging.CordaRPCOps
import net.corda.core.messaging.vaultQueryBy
import java.text.DecimalFormat
import java.util.*
import java.util.TreeMap
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

import kotlin.collections.HashSet

class ReportGenApi()
{
    fun valueCategory_Project(vctStates: List<ValueContractTransactionVO>): ArrayList<ValueCategoryVO>
    {
        var valueCategoryVO = ValueCategoryVO()
        var valueCategoryVOList = ArrayList<ValueCategoryVO>()
        var retention = 0
        var premium = 0
        var addition = 0
        val yearArray= yearlist(vctStates)
        val projectIdArray = projectlist(vctStates)

        for(k in yearArray.indices)
        {
            var year = yearArray[k]
            for (j in projectIdArray.indices)
            {
               var count = 0
               retention = 0
               premium = 0
               addition = 0
               var projectid = projectIdArray[j]
                for (i in vctStates.indices)
                {
                    if(count == 0){
                        valueCategoryVO = ValueCategoryVO()
                    }
                    var vctYear = yearfetch(vctStates[i].implementationDate)
                    if(vctYear == year && vctStates[i].projectId == projectid)
                    {
                        when {
                            vctStates[i].valueCategory == "Retention" -> retention += vctStates[i].agreedServiceCredits
                            vctStates[i].valueCategory == "Premium" -> premium += vctStates[i].agreedServiceCredits
                            else -> addition += vctStates[i].agreedServiceCredits
                        }

                        valueCategoryVO.projectId = vctStates[i].projectId
                        valueCategoryVO.valueRetention = retention
                        valueCategoryVO.valueAddition = addition
                        valueCategoryVO.valuePremium = premium
                        valueCategoryVO.year = vctYear
                        count++
                    }
                }
                if(count>0) {
                    valueCategoryVOList.add(valueCategoryVO)

                }
            }
        }
        return valueCategoryVOList
    }

    fun leverCategory_Project(vctStates: List<ValueContractTransactionVO>): ArrayList<LeverCategoryVO>
    {
        var leverCategoryVO=LeverCategoryVO()
        var leverCategoryVOList = ArrayList<LeverCategoryVO>()
        var csi = 0
        var transformation = 0
        var automation = 0
        var eliminate = 0
        var indus=0
        var trans_synergize = 0
        val yearArray= yearlist(vctStates)
        val projectIdArray = projectlist(vctStates)

        for(k in yearArray.indices)
        {
            var year = yearArray[k]
            for (j in projectIdArray.indices)
            {
                var count = 0
                csi = 0
                transformation = 0
                automation = 0
                eliminate = 0
                trans_synergize = 0
                var projectid = projectIdArray[j]
                for (i in vctStates.indices)
                {
                    if(count == 0){
                        leverCategoryVO = LeverCategoryVO()
                    }
                    var vctYear = yearfetch(vctStates[i].implementationDate)
                    if(vctYear == year && vctStates[i].projectId == projectid)
                    {
                        when {
                            vctStates[i].leverCategory == "CSI" -> csi += vctStates[i].agreedServiceCredits
                            vctStates[i].leverCategory == "Transformation" -> transformation += vctStates[i].agreedServiceCredits
                            vctStates[i].leverCategory == "Automation" -> automation += vctStates[i].agreedServiceCredits
                            vctStates[i].leverCategory == "Eliminate" -> eliminate += vctStates[i].agreedServiceCredits
                            vctStates[i].leverCategory == "Industrialization" -> indus+= vctStates[i].agreedServiceCredits
                            else -> trans_synergize += vctStates[i].agreedServiceCredits
                        }

                        leverCategoryVO.projectId = vctStates[i].projectId
                        leverCategoryVO.csi = csi
                        leverCategoryVO.transformation = transformation
                        leverCategoryVO.automation = automation
                        leverCategoryVO.eliminate = eliminate
                        leverCategoryVO.industrialization = indus
                        leverCategoryVO.transformationSynergize = trans_synergize
                        leverCategoryVO.year = vctYear
                        count++
                    }
                }
                if(count>0) {
                    leverCategoryVOList.add(leverCategoryVO)

                }
            }
        }
        return leverCategoryVOList
    }


    fun theme_Project(vctStates: List<ValueContractTransactionVO>): ArrayList<ThemeCategoryVO>
    {
        var themeVO= ThemeCategoryVO()
        var themeVOList = ArrayList<ThemeCategoryVO>()
        var run = 0
        var transform = 0
        var grow = 0
        var risk = 0
        val yearArray= yearlist(vctStates)
        val projectIdArray = projectlist(vctStates)

        for(k in yearArray.indices)
        {
            var year = yearArray[k]
            for (j in projectIdArray.indices)
            {
                var count = 0
                run = 0
                transform = 0
                grow = 0
                risk = 0
                var projectid = projectIdArray[j]
                for (i in vctStates.indices)
                {
                    if(count == 0){
                        themeVO = ThemeCategoryVO()
                    }
                    var vctYear = yearfetch(vctStates[i].implementationDate)
                    if(vctYear == year && vctStates[i].projectId == projectid)
                    {
                        when {
                            vctStates[i].theme == "Run the business" -> run += vctStates[i].agreedServiceCredits
                            vctStates[i].theme == "Transform the business" -> transform += vctStates[i].agreedServiceCredits
                            vctStates[i].theme == "Grow the business" -> grow += vctStates[i].agreedServiceCredits
                            else -> risk += vctStates[i].agreedServiceCredits
                        }

                        themeVO.projectId = vctStates[i].projectId
                        themeVO.runTheBusiness = run
                        themeVO.transformTheBusiness = transform
                        themeVO.growTheBusiness = grow
                        themeVO.RiskTheBusiness = risk
                        themeVO.year = vctYear
                        count++
                    }
                }
                if(count>0) {
                    themeVOList.add(themeVO)

                }
            }
        }
        return themeVOList
    }

    private fun yearfetch(date: Date?): Int
    {
        val c = Calendar.getInstance()
        c.time = date
        return c.get(Calendar.YEAR)
    }

    private  fun quarterfetch(date: Date?):String
    {
        val c = Calendar.getInstance()
        c.time = date
        val month = c.get(Calendar.MONTH)
        println("Month==> "+month)
        val quarter = if (month / 3 <= 1) "Q1" else if (month / 3 <= 2) "Q2" else if (month / 3 <= 3) "Q3" else "Q4"
        println("quarter==> "+quarter)
        return  quarter
    }

    private  fun quarterlist(vctStates: List<ValueContractTransactionVO>): Array<Int?>
    {
        val yearList:ArrayList<String> = vctStates.indices.mapTo(ArrayList<String>()) { quarterfetch(vctStates[it].implementationDate) }

        val yearHashList = HashSet(yearList)

        return yearHashList.toArray(arrayOfNulls<Int>(yearHashList.size))
    }

    private  fun yearlist(vctStates: List<ValueContractTransactionVO>): Array<Int?>
    {
        val yearList:ArrayList<Int> = vctStates.indices.mapTo(ArrayList<Int>()) { yearfetch(vctStates[it].implementationDate) }

        val yearHashList = HashSet(yearList)

        return yearHashList.toArray(arrayOfNulls<Int>(yearHashList.size))
    }

    private fun projectlist(vctStates: List<ValueContractTransactionVO>): Array<Int?>
    {
        val projectIdList:ArrayList<Int> = vctStates.indices.mapTo(ArrayList<Int>()) { vctStates[it].projectId }
        /*
        for(i in vctStates.indices)
        {
            projectIdList.add(vctStates[i].projectId)
        }*/
        val projectIdHashList = HashSet(projectIdList)
        return projectIdHashList.toArray(arrayOfNulls<Int>(projectIdHashList.size))
    }

     fun getDetails(AllAUV:ArrayList<ServiceCreditVO>,AllVCT:ArrayList<ValueContractTransactionVO>,role:String,param:List<String>,all:Boolean):DashboardVO
    {
        var dashboard=DashboardVO()

        //dashboard.auvCount=0

        when {
            role == "OperationalCognizant" || role == "PrimaryTactical" || role == "SecondaryTactical" ||role == "TacticalCustomer"||role=="StrategicCustomer"-> {

                if(param.isEmpty())
                {
                    var allprojectList=ArrayList<Int>()

                    for(i in AllAUV.indices)
                    {
                        if(AllAUV[i].status.equals("Approved",ignoreCase = true)) {
                            dashboard.approvedAuvCount+=1
                            dashboard.approvedTotalServiceCreditsCommitted += AllAUV[i].serviceCredit
                            allprojectList.add(AllAUV[i].projectId)
                        }
                        else
                        {
                            dashboard.pendingAuvCount+=1
                            dashboard.pendingTotalServiceCreditsCommitted += AllAUV[i].serviceCredit
                        }

                    }
                    dashboard.auvCount=dashboard.approvedAuvCount+dashboard.pendingAuvCount
                    val arrayList=ArrayList<Int>(HashSet(allprojectList))
                    dashboard.projectList=arrayList
                    dashboard.serviceCreditsCommitted=dashboard.approvedTotalServiceCreditsCommitted
                    for(j in AllVCT.indices)
                    {
                        if(AllVCT[j].isimplemented) {
                            when {
                                AllVCT[j].status == "Authorized" -> dashboard.implementedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Submitted" -> dashboard.implementedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Approved" -> dashboard.implementedServiceCreditsApproved += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Rejected" -> dashboard.implementedServiceCreditsRejected += AllVCT[j].agreedServiceCredits
                            }
                        }
                        else
                        {
                            when {
                                AllVCT[j].status == "Authorized" -> dashboard.plannedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Submitted" -> dashboard.plannedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Approved" -> dashboard.plannedServiceCreditsApproved += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Rejected" -> dashboard.plannedServiceCreditsRejected += AllVCT[j].agreedServiceCredits
                            }
                        }


                    }
                }
                else
                {

                    var list = getAUV(role, AllAUV, param)
                    var allprojectList=ArrayList<Int>()
                    for(i in list.indices)
                    {
                        if(list[i].status.equals("Approved",ignoreCase = true))
                            allprojectList.add(list[i].projectId)
                    }

                    var projectList=ArrayList<Int>(HashSet(allprojectList))

                    var vct = getVCT(AllVCT, projectList,true)

                    if (all) {
                        for (i in list.indices) {
                            if(list[i].status.equals("Approved",ignoreCase = true)) {
                                dashboard.approvedAuvCount+=1
                                dashboard.approvedTotalServiceCreditsCommitted += list[i].serviceCredit
                            }
                            else
                            {
                                dashboard.pendingAuvCount+=1
                                dashboard.pendingTotalServiceCreditsCommitted += list[i].serviceCredit
                            }
                        }
                        dashboard.serviceCreditsCommitted +=dashboard.approvedTotalServiceCreditsCommitted
                        dashboard.auvCount=dashboard.approvedAuvCount+dashboard.pendingAuvCount
                    }

                    for (i in list.indices) {
                        if(list[i].status.equals("Approved",ignoreCase = true)&&!all) {
                            dashboard.serviceCreditsCommitted += list[i].serviceCredit
                        }

                    }
                    for (j in vct.indices)
                    {
                        if(vct[j].isimplemented) {
                            when {
                                vct[j].status == "Authorized" -> dashboard.implementedServiceCreditsPending += vct[j].agreedServiceCredits
                                vct[j].status == "Submitted" -> dashboard.implementedServiceCreditsPending += vct[j].agreedServiceCredits
                                vct[j].status == "Approved" -> dashboard.implementedServiceCreditsApproved += vct[j].agreedServiceCredits
                                vct[j].status == "Rejected" -> dashboard.implementedServiceCreditsRejected += vct[j].agreedServiceCredits
                            }
                        }
                        else
                        {
                            when {
                                vct[j].status == "Authorized" -> dashboard.plannedServiceCreditsPending += vct[j].agreedServiceCredits
                                vct[j].status == "Submitted" -> dashboard.plannedServiceCreditsPending += vct[j].agreedServiceCredits
                                vct[j].status == "Approved" -> dashboard.plannedServiceCreditsApproved += vct[j].agreedServiceCredits
                                vct[j].status == "Rejected" -> dashboard.plannedServiceCreditsRejected += vct[j].agreedServiceCredits
                            }
                        }

                    }
                }
            }
            role=="StrategicCognizant"->{


                for(i in AllAUV.indices)
                {
                    if(AllAUV[i].status.equals("Approved",ignoreCase = true)) {
                        dashboard.approvedAuvCount+=1
                        dashboard.approvedTotalServiceCreditsCommitted += AllAUV[i].serviceCredit
                    }
                    else
                    {
                        dashboard.pendingAuvCount+=1
                        dashboard.pendingTotalServiceCreditsCommitted += AllAUV[i].serviceCredit
                    }
                }
                dashboard.auvCount=dashboard.approvedAuvCount+dashboard.pendingAuvCount
                dashboard.serviceCreditsCommitted=dashboard.approvedTotalServiceCreditsCommitted
                for(j in AllVCT.indices)
                {

                    if(AllVCT[j].isimplemented) {
                        when {
                            AllVCT[j].status == "Authorized" -> dashboard.implementedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                            AllVCT[j].status == "Submitted" -> dashboard.implementedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                            AllVCT[j].status == "Approved" -> dashboard.implementedServiceCreditsApproved += AllVCT[j].agreedServiceCredits
                            AllVCT[j].status == "Rejected" -> dashboard.implementedServiceCreditsRejected += AllVCT[j].agreedServiceCredits
                        }
                    }
                    else
                    {
                        when {
                            AllVCT[j].status == "Authorized" -> dashboard.plannedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                            AllVCT[j].status == "Submitted" -> dashboard.plannedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                            AllVCT[j].status == "Approved" -> dashboard.plannedServiceCreditsApproved += AllVCT[j].agreedServiceCredits
                            AllVCT[j].status == "Rejected" -> dashboard.plannedServiceCreditsRejected += AllVCT[j].agreedServiceCredits
                        }
                    }

                }
            }
            role=="OperationalCustomer"->{
                if(param.isEmpty())
                {
                    var allprojectList=AllVCT.map { it.projectId }as ArrayList<Int>
                    dashboard.auvCount=AllVCT.size
                    /*for(i in AllVCT.indices)
                    {
                            dashboard.approvedTotalServiceCreditsCommitted += AllVCT[i].agreedServiceCredits
                            allprojectList.add(AllVCT[i].projectId)
                    }
                   val hashList=HashSet(allprojectList)*/
                    val arrayList=ArrayList<Int>(HashSet(allprojectList))
                    dashboard.projectList=arrayList
                    //dashboard.serviceCreditsCommitted=dashboard.approvedTotalServiceCreditsCommitted
                    for(j in AllVCT.indices)
                    {

                        if(AllVCT[j].isimplemented) {
                            when {
                                AllVCT[j].status == "Authorized" -> dashboard.implementedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Submitted" -> dashboard.implementedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Approved" -> dashboard.implementedServiceCreditsApproved += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Rejected" -> dashboard.implementedServiceCreditsRejected += AllVCT[j].agreedServiceCredits
                            }
                        }
                        else
                        {
                            when {
                                AllVCT[j].status == "Authorized" -> dashboard.plannedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Submitted" -> dashboard.plannedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Approved" -> dashboard.plannedServiceCreditsApproved += AllVCT[j].agreedServiceCredits
                                AllVCT[j].status == "Rejected" -> dashboard.plannedServiceCreditsRejected += AllVCT[j].agreedServiceCredits
                            }
                        }

                    }

                }
                else
                {
                    for(i in param.indices)
                    {
                        for(j in AllVCT.indices)
                        {
                            if(AllVCT[j].projectId.toString().equals(param[i]))
                            {
                                //dashboard.serviceCreditsCommitted+=AllVCT[j].agreedServiceCredits
                                if(AllVCT[j].isimplemented) {
                                    when {
                                        AllVCT[j].status == "Authorized" -> dashboard.implementedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                        AllVCT[j].status == "Submitted" -> dashboard.implementedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                        AllVCT[j].status == "Approved" -> dashboard.implementedServiceCreditsApproved += AllVCT[j].agreedServiceCredits
                                        AllVCT[j].status == "Rejected" -> dashboard.implementedServiceCreditsRejected += AllVCT[j].agreedServiceCredits
                                    }
                                }
                                else
                                {
                                    when {
                                        AllVCT[j].status == "Authorized" -> dashboard.plannedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                        AllVCT[j].status == "Submitted" -> dashboard.plannedServiceCreditsPending += AllVCT[j].agreedServiceCredits
                                        AllVCT[j].status == "Approved" -> dashboard.plannedServiceCreditsApproved += AllVCT[j].agreedServiceCredits
                                        AllVCT[j].status == "Rejected" -> dashboard.plannedServiceCreditsRejected += AllVCT[j].agreedServiceCredits
                                    }
                                }

                            }
                        }

                    }

                }

            }


        }
        return dashboard

    }

     fun getreportDetails(allAUV:ArrayList<ServiceCreditVO>,allVCT:ArrayList<ValueContractTransactionVO>,role:String,param:List<String>):ValueCategory
    {
        var valueCategory=ValueCategory()

        var overallcategory=ArrayList<ProjectDetails>()
        var overallservicecredits=ArrayList<Category>()

        var allvalcat=Category()

        when
        {
            role=="OperationalCognizant"||role=="PrimaryTactical"||role=="TacticalCustomer"||role=="OperationalCustomer"->
            {
                var list:ArrayList<ServiceCreditVO>
                if(role.equals("TacticalCustomer",ignoreCase = true)) {
                    list=allAUV
                }
                else
                {
                    list = getAUV(role, allAUV, param)
                }
                var allprojectList=ArrayList<Int>()
                for(i in list.indices)
                {
                    if(list[i].status.equals("Approved",ignoreCase = true))
                        allprojectList.add(list[i].projectId)
                }

              if(role.equals("OperationalCustomer",ignoreCase = true))
                    allprojectList=allVCT.map { it.projectId }as ArrayList<Int>

                var projectList=ArrayList<Int>(HashSet(allprojectList))

                var vct = getVCT(allVCT, projectList,false)


                for(i in projectList.indices)
                {
                    val projectdetail=ProjectDetails()

                    var category=ArrayList<Category>()

                    var valcat=Category()

                    for(k in vct.indices) {
                        if(vct[k].projectId==projectList[i]) {
                            projectdetail.projectID = vct[k].projectId.toString()
                            projectdetail.projectName=vct[k].projectName
                            break
                        }
                    }
                    for(j in vct.indices)
                    {
                        if(projectList[i]==vct[j].projectId&&vct[j].status.equals("Approved"))
                        {
                                projectdetail.totalServiceCredits += vct[j].agreedServiceCredits
                                when {
                                    vct[j].valueCategory == "Premium" -> valcat.Premium += vct[j].agreedServiceCredits
                                    vct[j].valueCategory == "Addition" -> valcat.Addition += vct[j].agreedServiceCredits
                                    vct[j].valueCategory == "Retention" -> valcat.Retention += vct[j].agreedServiceCredits
                                }
                            }
                    }
                    allvalcat.Premium+=valcat.Premium
                    allvalcat.Addition+=valcat.Addition
                    allvalcat.Retention+=valcat.Retention
                    category.add(valcat)
                    projectdetail.valueCategory=category
                    overallcategory.add(projectdetail)
                }
                overallservicecredits.add(allvalcat)
                valueCategory.overAllCategory=overallcategory
                valueCategory.overAllServiceCredits=overallservicecredits
            }
            role=="SecondaryTactical"->
            {
               var customerList=getAUV(role,allAUV,param)
                var cusList=ArrayList<String>()

                for(i in customerList.indices)
                    cusList.add(customerList[i].customerName!!)

                val arrayList=ArrayList<String>(HashSet(cusList))
                for(i in arrayList.indices)
                {
                    var list=ArrayList<String>()
                    val projectdetail=ProjectDetails()

                    var category=ArrayList<Category>()

                    var valcat=Category()

                    projectdetail.projectID=arrayList[i]
                    list.add(arrayList[i])
                    var auv = getAUV("PrimaryTactical",customerList,list)
                    var projectList=auv.map { it.projectId } as ArrayList<Int>
                    projectList= ArrayList<Int>(HashSet(projectList))

                    var vct=getVCT(allVCT,projectList,false)
                    for(j in vct.indices)
                    {
                        if(vct[j].status.equals("Approved",ignoreCase = true)) {
                            projectdetail.totalServiceCredits += vct[j].agreedServiceCredits
                            when {
                                vct[j].valueCategory == "Premium" -> valcat.Premium += vct[j].agreedServiceCredits
                                vct[j].valueCategory == "Addition" -> valcat.Addition += vct[j].agreedServiceCredits
                                vct[j].valueCategory == "Retention" -> valcat.Retention += vct[j].agreedServiceCredits
                            }
                        }

                    }
                    allvalcat.Premium+=valcat.Premium
                    allvalcat.Addition+=valcat.Addition
                    allvalcat.Retention+=valcat.Retention
                    category.add(valcat)
                    projectdetail.valueCategory=category
                    overallcategory.add(projectdetail)
                }
                overallservicecredits.add(allvalcat)
                valueCategory.overAllCategory=overallcategory
                valueCategory.overAllServiceCredits=overallservicecredits

                }

        }

        return valueCategory
    }

    fun getAdditionalGraphDetails(AllAUV:ArrayList<ServiceCreditVO>,AllVCT:ArrayList<ValueContractTransactionVO>,role:String,param:List<String>):AdditionalGraphVO
    {
        var additionalGraphVO=AdditionalGraphVO()
        var stackedBar=ArrayList<StackedBar>()
        var overallList=ArrayList<Overall>()
        var overall=Overall()
        when
        {
            role=="OperationalCognizant"||role=="PrimaryTactical"-> {
                       var paramList=ArrayList<Int>()

                       var list = getAUV(role, AllAUV, param)

                       for(i in list.indices)
                       {
                           if(list[i].status.equals("Approved",ignoreCase = true))
                           paramList.add(list[i].projectId)
                       }

                var projectList=ArrayList<Int>(HashSet(paramList))

                       var vct = getVCT(AllVCT, projectList,false)

                       for (i in projectList.indices) {
                           var stack = StackedBar()

                           for(k in list.indices) {
                               if(list[k].projectId==projectList[i])
                                   stack.projectid = list[k].projectName
                           }

                          // stack.projectid = paramList[i]

                           for (j in vct.indices) {
                               if (vct[j].projectId==projectList[i]) {
                                   when {

                                       vct[j].status == "Authorized" -> stack.pending += vct[j].agreedServiceCredits
                                       vct[j].status == "Submitted" -> stack.pending += vct[j].agreedServiceCredits
                                       vct[j].status == "Approved" -> stack.approved += vct[j].agreedServiceCredits
                                       vct[j].status == "Rejected" -> stack.rejected += vct[j].agreedServiceCredits
                                   }

                               }
                           }
                           overall.approved+=stack.approved
                           overall.pending+=stack.pending
                           overall.rejected+=stack.rejected
                           stackedBar.add(stack)
                       }
                       additionalGraphVO.StackedBar = stackedBar
                        overallList.add(overall)
                        additionalGraphVO.overAllServiceCredits=overallList

                       var details=getDetails(AllAUV,AllVCT,role,param,false)
                additionalGraphVO.percent= ((details.implementedServiceCreditsApproved*100)/details.serviceCreditsCommitted).toDouble()


            }
        }
        return additionalGraphVO
    }
    fun getDashboardGraph(allAUV:ArrayList<ServiceCreditVO>,allVCT:ArrayList<ValueContractTransactionVO>,role:String,param:List<String>):ValueCategory
    {
        val valueCategory=ValueCategory()
        //val dynamictreemap=ArrayList<BU>()
        val treemap=ArrayList<com.valuemanagement.model.TreeMap>()
        when {
            role == "OperationalCognizant" || role == "PrimaryTactical" ||role=="TacticalCustomer"||role=="StrategicCustomer"-> {

                var paramList = ArrayList<Int>()

                var list:ArrayList<ServiceCreditVO>

                if(role.equals("TacticalCustomer",ignoreCase = true)||role.equals("StrategicCustomer",ignoreCase = true)) {
                    list=allAUV
                }
                else
                {
                    list = getAUV(role, allAUV, param)
                }

                for (i in list.indices) {
                    if (list[i].status.equals("Approved", ignoreCase = true))
                        paramList.add(list[i].projectId)
                }


                var projectList=ArrayList<Int>(HashSet(paramList))

                var vct = getVCT(allVCT, projectList,false)


                for(i in vct.indices)
                {
                    val tree=com.valuemanagement.model.TreeMap()

                    tree.projectName=vct[i].projectName
                    when {
                        vct[i].status == "Approved" -> {
                            tree.status = "Approved"
                            tree.value = vct[i].agreedServiceCredits
                            tree.transactionID = vct[i].transactionID
                            tree.initiator=vct[i].transactioninitiator
                            tree.authorizer=vct[i].transactionauthorizerName
                            tree.approver=vct[i].transactionapproverName
                        }
                        vct[i].status == "Authorized" -> {
                            tree.status = "In_Progress"
                            tree.value = vct[i].agreedServiceCredits
                            tree.transactionID = vct[i].transactionID
                            tree.initiator=vct[i].transactioninitiator
                            tree.authorizer=vct[i].transactionauthorizerName
                            tree.approver=vct[i].transactionapproverName
                        }
                        vct[i].status == "Submitted" -> {
                            tree.status = "In_Progress"
                            tree.value = vct[i].agreedServiceCredits
                            tree.transactionID = vct[i].transactionID
                            tree.initiator=vct[i].transactioninitiator
                            tree.authorizer=vct[i].transactionauthorizerName
                            tree.approver=vct[i].transactionapproverName
                        }
                        vct[i].status == "Rejected" -> {
                            tree.status = "Rejected"
                            tree.value = vct[i].agreedServiceCredits
                            tree.transactionID = vct[i].transactionID
                            tree.initiator=vct[i].transactioninitiator
                            tree.authorizer=vct[i].transactionauthorizerName
                            tree.approver=vct[i].transactionapproverName
                        }
                    }
                    treemap.add(tree)
                }
                valueCategory.treeMap=treemap

            }
            role=="SecondaryTactical"->
            {
                var treemap=ArrayList<BU>()

                for(i in param.indices)
                {

                    var list=ArrayList<String>()
                    var bu=BU()
                    bu.name=param[i]
                    var bulist=ArrayList<Account>()
                    list.add(param[i])
                    println("param11111====="+list)
                    var buProjectList=getAUV(role,allAUV,list)
                    var projectList=buProjectList.map { it.customerName } as ArrayList
                    projectList=ArrayList(HashSet(projectList))
                    println("buprojectList=========="+projectList)
                    for(j in projectList.indices)
                    {
                        var account=Account()
                        var projectlist=ArrayList<Int>()
                        account.name=projectList[i]
                        var accountList=ArrayList<Project>()
                        var customer=ArrayList<String>()
                        customer.add(projectList[j].toString())
                        println("customername========="+customer)
                        var auv = getAUV("PrimaryTactical",buProjectList,customer)
                        for(c in auv.indices)
                        {
                            if (auv[c].status.equals("Approved", ignoreCase = true))
                                projectlist.add(auv[c].projectId)
                        }
                       // var projectlist=auv.map { it.projectId } as ArrayList<Int>
                        projectlist= ArrayList<Int>(HashSet(projectlist))
                        println("cusprojectList====="+projectlist)
                        var vct=getVCT(allVCT,projectlist,false)
                        for(k in projectlist.indices)
                        {
                            var project=Project()
                            for(l in vct.indices)
                            {
                                if(vct[l].projectId==projectlist[k]&&vct[l].status.equals("Approved",ignoreCase = true)) {
                                    project.name=vct[l].projectName
                                    project.size += vct[l].agreedServiceCredits
                                }
                            }
                            accountList.add(project)

                        }
                        account.children=accountList
                        bulist.add(account)
                    }
                    bu.children=bulist
                    treemap.add(bu)

                }
                valueCategory.children=treemap
            }
        }

        return valueCategory
    }



    private fun getAUV(role:String,AllAUV: ArrayList<ServiceCreditVO>, param:List<String>):ArrayList<ServiceCreditVO>
    {
       /* var AllAUV=ArrayList<ServiceCreditVO>()
        for(i in allAUV.indices)
        {
            if(allAUV[i].status.equals("Approved",ignoreCase = true))
                AllAUV.add(allAUV[i])
        }*/

        var auvList=ArrayList<ServiceCreditVO>()

                    when
                    {
                        role=="OperationalCognizant"||role=="TacticalCustomer"||role=="StrategicCustomer"->{
                            for (i in AllAUV.indices) {
                                for (j in param.indices) {
                                    if (param[j].equals(AllAUV[i].projectId.toString()))
                                        auvList.add(AllAUV[i])
                                }
                            }
                        }
                        role=="PrimaryTactical"->{
                            for (i in AllAUV.indices) {
                                for (j in param.indices) {
                                    if (param[j].equals(AllAUV[i].customerName, ignoreCase = true))
                                        auvList.add(AllAUV[i])
                                }
                            }
                        }
                        role=="SecondaryTactical"->{
                                    for (i in AllAUV.indices) {
                                        for (j in param.indices) {
                                            if (param[j].equals(AllAUV[i].businessUnit, ignoreCase = true))
                                                auvList.add(AllAUV[i])
                                        }
                                    }
                        }


                    }


            return auvList
    }

    private fun getVCT(AllVCT: ArrayList<ValueContractTransactionVO>, AllAUV:ArrayList<Int>,flag:Boolean):ArrayList<ValueContractTransactionVO>
    {

        var vctList = ArrayList<ValueContractTransactionVO>()


        for (i in AllAUV.indices) {

            for (j in AllVCT.indices) {

                if (AllAUV[i]==AllVCT[j].projectId&&flag) {
                    vctList.add(AllVCT[j])

                }
                else
                {
                    if (AllAUV[i]==AllVCT[j].projectId&&AllVCT[j].isimplemented) {
                        vctList.add(AllVCT[j])

                    }
                }
            }
        }

        return vctList

    }

}