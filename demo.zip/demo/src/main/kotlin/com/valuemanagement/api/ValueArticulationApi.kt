/*
 * Copyright (c) 2017. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.valuemanagement.api

import com.valuemanagement.flow.ApproveServiceCreditFlow.Approver
import com.valuemanagement.flow.ApproveValueTransactionFlow.ValueContractApprover
import com.valuemanagement.flow.AuthorizeServiceCreditFlow.Authorizer
import com.valuemanagement.flow.AuthorizeValueTransactionFlow.ValueContractAuthorizer
import com.valuemanagement.flow.CreateServiceCreditFlow.Initiator
import com.valuemanagement.flow.ExecuteValueTransactionFlow.ValueContractInitiator
import com.valuemanagement.flow.ReviseServiceCreditFlow.RevisedInitiator
import com.valuemanagement.flow.ReviseValueTransactionFlow.RevisedValueContractApprover
import com.valuemanagement.model.*
import com.valuemanagement.schema.PersistentServiceCredits
import com.valuemanagement.schema.PresisentValueContractTransaction
import com.valuemanagement.state.CreateServiceCreditState
import com.valuemanagement.state.ValueContractTransactionState
import com.valuemanagement.validation.ValueArticulationValidation
import net.corda.core.crypto.SecureHash
import net.corda.core.identity.CordaX500Name
import net.corda.core.identity.Party
import net.corda.core.messaging.CordaRPCOps
import net.corda.core.messaging.FlowProgressHandle
import net.corda.core.messaging.startTrackedFlow
import net.corda.core.messaging.vaultQueryBy
import net.corda.core.node.services.Vault
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.builder
import net.corda.core.transactions.SignedTransaction
import net.corda.core.utilities.getOrThrow
import net.corda.core.utilities.loggerFor
import org.slf4j.Logger
import java.io.File
import java.io.InputStream
import java.util.*
import javax.ws.rs.*
import javax.ws.rs.core.MediaType
import javax.ws.rs.core.Response
import javax.ws.rs.core.Response.Status.BAD_REQUEST
import javax.ws.rs.core.Response.Status.OK
import kotlin.collections.ArrayList

val SERVICE_NAMES = listOf("Controller", "Network Map Service")

// This API is accessible from /api/valueArticulation. All paths specified below are relative to it.
@Path("valueArticulation")
class ValueArticulationApi(private val rpcOps: CordaRPCOps) {
    private val myLegalName: CordaX500Name = rpcOps.nodeInfo().legalIdentities.first().name
    val valueCategoryVO = ValueCategoryVO()
    val leverCategoryVO = LeverCategoryVO()

    companion object {
        private val logger: Logger = loggerFor<ValueArticulationApi>()
    }

    /**
     * Returns the node's name.
     */


    @GET
    @Path("me")
    @Produces(MediaType.APPLICATION_JSON)
    fun whoami() = mapOf("me" to myLegalName)

    /**
     * Returns all parties registered with the [NetworkMapService]. These names can be used to look up identities
     * using the [IdentityService].
     */

    @GET
    @Path("peers")
    @Produces(MediaType.APPLICATION_JSON)
    fun getPeers(): Map<String, List<CordaX500Name>> {
        val nodeInfo = rpcOps.networkMapSnapshot()
        return mapOf("peers" to nodeInfo
                .map { it.legalIdentities.first().name }
                //filter out myself, notary and eventual network map started by driver
                .filter { it.organisation !in (SERVICE_NAMES + myLegalName.organisation) })
    }

    /**
     * Displays all Service Credits states that exist in the node's vault.
     */



   /* @GET
    @Path("getAll_AUV")
    @Produces(MediaType.APPLICATION_JSON)
    fun getIOUs(): List<ServiceCreditVO> {
        // Extract the IOUState StateAndRefs from the vault.
        val iouStateAndRefs = rpcOps.vaultQueryBy<CreateServiceCreditState>().states

        // Map each StateAndRef to its IOUState.
        val iouStates = iouStateAndRefs.map { it.state.data.serviceCreditVO }
        return iouStates
    }*/
    @GET
    @Path("getAll_AUV")
    @Produces(MediaType.APPLICATION_JSON)
    fun get():ArrayList<ServiceCreditVO>
    {
        return getAUV()
    }
    /**
     * Displays all Value Contract Transaction states that exist in the node's vault.
     */

    @GET
    @Path("getAll_VCT")
    @Produces(MediaType.APPLICATION_JSON)
    fun getIOU(): ArrayList<ValueContractTransactionVO> {
        // Extract the IOUState StateAndRefs from the vault.
        val iouStateAndRefs = rpcOps.vaultQueryBy<ValueContractTransactionState>().states

        // Map each StateAndRef to its IOUState.
        val iouStates = iouStateAndRefs.map { it.state.data.valueContractTransactionVO }

        var vctList=ArrayList<ValueContractTransactionVO>()

        for(i in iouStates.indices)
        {
            vctList.add(vctUpdatedComment(iouStates[i]))
        }

        return vctList
    }

    /*@GET
    @Path("getAll_VCT")
    @Produces(MediaType.APPLICATION_JSON)
    fun getIOU(): ArrayList<ValueContractTransactionVO> {
        // Extract the IOUState StateAndRefs from the vault.
        return getVCT(false, Collections.emptyList())
    }*/


    /**
     * Opens the uploaded attachment
     */

    @GET
    @Path("viewattachment")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
            //fun getAttachment() = rpcOps.openAttachment(SecureHash.parse(attachmentHash))
    fun getAttachment(@QueryParam("attachmentHash") attachmentHash: String) : Response {
        val inputString = rpcOps.openAttachment(SecureHash.parse(attachmentHash)).bufferedReader().use { it.readText() }
        val file = File("OutputFile.txt")
        file.writeText(inputString)

        return Response.ok("File downloaded successfully in the path").build();
    }


    /**
     * Initiates a flow to agree an Service Credits between two parties.( SDM Cognizant and SDD Cognizant)
     *
     * Once the flow finishes it will have written the Service Credit to ledger. Both the InitiatorCognizant and the AuthorizerCognizant will be able to
     * see it when calling /api/valueArticulation/serviceCredits on their respective nodes.
     *
     * This end-point takes a Party name parameter as part of the path. If the serving node can't find the other party
     * in its network map cache, it will return an HTTP bad request.
     *
     * The flow is invoked asynchronously. It returns a future when the flow's call() method returns.
     */

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("create-serviceCredits")
    fun createServiceCredits(serviceCreditVO : ServiceCreditVO): Response {
        // Business validation starts here
        if (serviceCreditVO.serviceCredit <= 0 && serviceCreditVO.serviceCredit >= 99999) {
            return Response.status(BAD_REQUEST).entity("Query parameter 'serviceCredit' must be non-negative or greater than 99999.\n").build()
        }

        // Business validation ends here
        var validationErrorVO=ValidationErrorVO()
        serviceCreditVO.auvId = UUID.randomUUID().toString();


        val ctsPrimaryAuthorizer = CordaX500Name("PrimaryAuthorizer", "New York", "US")

        val primaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsPrimaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsPrimaryAuthorizer cannot be found.\n").build()

        val ctsSecondaryAuthorizer = CordaX500Name("SecondaryAuthorizer", "New York", "US")

        val secondaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsSecondaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsSecondaryAuthorizer cannot be found.\n").build()
        val stratCognizant = CordaX500Name("StrategicCognizant", "London", "GB")

        val strategicCognizant = rpcOps.wellKnownPartyFromX500Name(stratCognizant) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCognizant cannot be found.\n").build()

        //Attachment code starts here
        /*val path = serviceCreditVO.attachmentPath
        if (serviceCreditVO.attachmentPath == null || serviceCreditVO.attachmentPath == "" || serviceCreditVO.attachmentPath == " ") {
            return Response.status(BAD_REQUEST).entity(" 'AttachmentPath' not exist").build()}

        val pathName = path!!.substringBeforeLast(".")
        val fileName = pathName.substringAfterLast("/")

        if (fileName == "" || fileName == " ") {
            return Response.status(BAD_REQUEST).entity(" 'File' not exist").build()
        }
        val attachmentInputStream: InputStream = File(serviceCreditVO.attachmentPath).inputStream()
        val attachmentHash = rpcOps.uploadAttachment(attachmentInputStream).toString()
        serviceCreditVO.attachment = attachmentHash*/
        return try {

            val existingProjectId=getAUV().map { it.projectId }

            if(existingProjectId.contains(serviceCreditVO.projectId)&&serviceCreditVO.projectScope.equals("Base",ignoreCase = true))
            {

             // return Response.status(OK).entity("This Project ID already exists for Projectscope:Base ").build()
                validationErrorVO.error="This Project ID already exists for Projectscope:Base"
                return Response.ok(validationErrorVO, MediaType.APPLICATION_JSON).build()
            }
            else
            {
                val flowHandle = rpcOps.startTrackedFlow(::Initiator, serviceCreditVO, primaryauthorizer, secondaryauthorizer, strategicCognizant)

                flowHandle.progress.subscribe { println(">> $it") }
                // Extract the IOUState StateAndRefs from the vault.
                var result=flowHandle.returnValue.getOrThrow()
                var resultState=result.tx.outputs.single().data as CreateServiceCreditState
                var resultServiceCredit=resultState.serviceCreditVO
                resultServiceCredit.transactionID=result.id.toString()
                val updatedVO = auvUpdatedComment(resultServiceCredit)
                Response.ok(updatedVO, MediaType.APPLICATION_JSON).build()
            }

        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
        //Attachment code ends here
    }

    /**
     * Initiates a flow to authorize a Service Credits between two parties.( SDD Cognizant and Customer)
     *
     * Once the flow finishes it will have written the Service Credit to ledger. Both the AuthorizerCognizant and the Customer will be able to
     * see it when calling /api/valueArticulation/serviceCredits on their respective nodes.
     *
     * This end-point takes a Party name parameter as part of the path. If the serving node can't find the other party
     * in its network map cache, it will return an HTTP bad request.
     *
     * The flow is invoked asynchronously. It returns a future when the flow's call() method returns.
     */

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("authorize-serviceCredits")
    fun authorizeServiceCredits(@QueryParam("authorizer")authorizers:String,serviceCreditVO : ServiceCreditVO ): Response {
        // Business validation starts here
        // service credit validation
        if (serviceCreditVO.serviceCredit <= 0 && serviceCreditVO.serviceCredit >= 99999) {
            return Response.status(BAD_REQUEST).entity("Query parameter 'serviceCredit' must be non-negative or greater than 99999.\n").build()
        }

        // Status field validation
        if(serviceCreditVO.status.equals("submit for approval")) {
            serviceCreditVO.status=="Authorized"
        }
        // Business validation ends here
        var validationErrorVO=ValidationErrorVO()
        val authorizer:Party
        val optional:Party

      val ctsinitiator=CordaX500Name("InitiatorCognizant","London","GB")
        val initiator=rpcOps.wellKnownPartyFromX500Name(ctsinitiator)?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsinitiator cannot be found.\n").build()

        val tactCustomer = CordaX500Name("TacticalCustomer", "Paris", "FR")

        val tacticalCustomer = rpcOps.wellKnownPartyFromX500Name(tactCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $tactCustomer cannot be found.\n").build()



        val ctsPrimaryAuthorizer = CordaX500Name("PrimaryAuthorizer", "New York", "US")

        val primaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsPrimaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsPrimaryAuthorizer cannot be found.\n").build()

        val ctsSecondaryAuthorizer = CordaX500Name("SecondaryAuthorizer", "New York", "US")

        val secondaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsSecondaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsSecondaryAuthorizer cannot be found.\n").build()

        if(authorizers.equals("PrimaryAuthorizer",ignoreCase = true))
        {
            authorizer=primaryauthorizer
            optional=secondaryauthorizer
        }
        else
        {
            authorizer=secondaryauthorizer
            optional=primaryauthorizer
        }

        val stratCognizant = CordaX500Name("StrategicCognizant", "London", "GB")

        val strategicCognizant = rpcOps.wellKnownPartyFromX500Name(stratCognizant) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCognizant cannot be found.\n").build()

        val stratCustomer = CordaX500Name("StrategicCustomer", "Paris", "FR")

        val strategicCustomer = rpcOps.wellKnownPartyFromX500Name(stratCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCustomer cannot be found.\n").build()

        val tacticalauthorizer=ArrayList<Party>()

        tacticalauthorizer.add(authorizer)
        tacticalauthorizer.add(optional)




        return try {
            //0 AUV
            if(serviceCreditVO.serviceCreditCommitted)
            {

                val flowHandle = rpcOps.startTrackedFlow(::Authorizer, serviceCreditVO,initiator,tacticalauthorizer, tacticalCustomer, strategicCognizant, strategicCustomer)
                flowHandle.progress.subscribe { println(">> $it") }
                var result=flowHandle.returnValue.getOrThrow()
                var resultState=result.tx.outputs.single().data as CreateServiceCreditState
                var resultServiceCredit=resultState.serviceCreditVO
                resultServiceCredit.transactionID=result.id.toString()
                val updatedVO = auvUpdatedComment(resultServiceCredit)
                Response.ok(updatedVO, MediaType.APPLICATION_JSON).build()
            }
            else{
                validationErrorVO.error="We shouldn't execute authorization for 0 AUV."
                return Response.ok(validationErrorVO, MediaType.APPLICATION_JSON).build()}


        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
    }


    /**
     * Initiates a flow to approve a Service Credits between two parties.( Customer and SDD)
     *
     * Once the flow finishes it will have written the Service Credit to ledger. Both the AuthorizerCognizant and the Customer will be able to
     * see it when calling /api/valueArticulation/serviceCredits on their respective nodes.
     *
     * This end-point takes a Party name parameter as part of the path. If the serving node can't find the other party
     * in its network map cache, it will return an HTTP bad request.
     *
     * The flow is invoked asynchronously. It returns a future when the flow's call() method returns.
     */

    @POST
    @Path("approve-serviceCredits")
    fun approveServiceCredits(serviceCreditVO : ServiceCreditVO): Response {

        // Business validation starts here
        // service credit validation
        if (serviceCreditVO.serviceCredit <= 0 && serviceCreditVO.serviceCredit >= 99999) {
            return Response.status(BAD_REQUEST).entity("Query parameter 'serviceCredit' must be non-negative or greater than 99999.\n").build()
        }

        // Status field validation
        if(serviceCreditVO.status.equals("submit to approve")) {
            serviceCreditVO.status=="Approved"
        }
        // Business validation ends here

        val ctsinitiator=CordaX500Name("InitiatorCognizant","London","GB")
        val initiator=rpcOps.wellKnownPartyFromX500Name(ctsinitiator)?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsinitiator cannot be found.\n").build()


        val ctsPrimaryAuthorizer = CordaX500Name("PrimaryAuthorizer", "New York", "US")

        val primaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsPrimaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsPrimaryAuthorizer cannot be found.\n").build()

        val ctsSecondaryAuthorizer = CordaX500Name("SecondaryAuthorizer", "New York", "US")

        val secondaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsSecondaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsSecondaryAuthorizer cannot be found.\n").build()


        val tactCustomer = CordaX500Name("TacticalCustomer", "Paris", "FR")

        val tacticalCustomer = rpcOps.wellKnownPartyFromX500Name(tactCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $tactCustomer cannot be found.\n").build()

        val stratCognizant = CordaX500Name("StrategicCognizant", "London", "GB")

        val strategicCognizant = rpcOps.wellKnownPartyFromX500Name(stratCognizant) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCognizant cannot be found.\n").build()

        val stratCustomer = CordaX500Name("StrategicCustomer", "Paris", "FR")

        val strategicCustomer = rpcOps.wellKnownPartyFromX500Name(stratCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCustomer cannot be found.\n").build()

        val tacticalauthorizer=ArrayList<Party>()

        tacticalauthorizer.add(primaryauthorizer)
        tacticalauthorizer.add(secondaryauthorizer)

        return try {
            val flowHandle = rpcOps.startTrackedFlow(::Approver, serviceCreditVO,initiator,tacticalauthorizer ,tacticalCustomer,strategicCognizant,strategicCustomer)
            flowHandle.progress.subscribe { println(">> $it") }
            var result=flowHandle.returnValue.getOrThrow()
            var resultState=result.tx.outputs.single().data as CreateServiceCreditState
            var resultServiceCredit=resultState.serviceCreditVO
            resultServiceCredit.transactionID=result.id.toString()
            val updatedVO = auvUpdatedComment(resultServiceCredit)
            Response.ok(updatedVO, MediaType.APPLICATION_JSON).build()
        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
    }

    /**
     * Initiates a flow to create value contract transaction for respective service credit Id.

     * Once finishes the creation, it ll create new value contract transaction Id for authorize the VCT.

     * If the lever category is "Retention" then the InitiatorCognizant, the AuthorizerCognizant and the OperationalCustomer  will be able to see it when calling /api/valueArticulation/ValueContract on their respective nodes.

     * If the lever category is "Addition or Premium" then the InitiatorCognizant and the AuthorizerCognizant will be able to see it when calling /api/valueArticulation/ValueContract on their respective nodes.

     * This end-point takes a Party name parameter as part of the path. If the serving node can't find the other party
    in its network map cache, it will return an HTTP bad request.

     * The flow is invoked asynchronously. It returns a future when the flow's call() method returns.
     */

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("execute-ValueContractTransaction")
    fun executeValueTransaction(valueContractTransactionVO : ValueContractTransactionVO): Response {

        if (valueContractTransactionVO.agreedServiceCredits <= 0) {
            return Response.status(BAD_REQUEST).entity("Query parameter 'serviceCredit' must be non-negative.\n").build()
        }

        val ctsinitiator=CordaX500Name("InitiatorCognizant","London","GB")
        val initiator=rpcOps.wellKnownPartyFromX500Name(ctsinitiator)?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsinitiator cannot be found.\n").build()


        val ctsPrimaryAuthorizer = CordaX500Name("PrimaryAuthorizer", "New York", "US")

        val primaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsPrimaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsPrimaryAuthorizer cannot be found.\n").build()

        val ctsSecondaryAuthorizer = CordaX500Name("SecondaryAuthorizer", "New York", "US")

        val secondaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsSecondaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsSecondaryAuthorizer cannot be found.\n").build()

        val tactCustomer = CordaX500Name("TacticalCustomer", "Paris", "FR")

        val tacticalCustomer = rpcOps.wellKnownPartyFromX500Name(tactCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $tactCustomer cannot be found.\n").build()

        val optCustomer = CordaX500Name("OperationalCustomer", "Paris", "FR")

        val operationalCustomer = rpcOps.wellKnownPartyFromX500Name(optCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $optCustomer cannot be found.\n").build()

        val stratCognizant = CordaX500Name("StrategicCognizant", "London", "GB")

        val strategicCognizant = rpcOps.wellKnownPartyFromX500Name(stratCognizant) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCognizant cannot be found.\n").build()

        val stratCustomer = CordaX500Name("StrategicCustomer", "Paris", "FR")

        val strategicCustomer = rpcOps.wellKnownPartyFromX500Name(stratCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCustomer cannot be found.\n").build()

        val counterParties= ArrayList<Party>()

        counterParties.add(strategicCognizant)

        counterParties.add(strategicCustomer)

        counterParties.add(tacticalCustomer)

        val tacticalauthorizer=ArrayList<Party>()

        tacticalauthorizer.add(primaryauthorizer)
        tacticalauthorizer.add(secondaryauthorizer)
        var validationErrorVO=ValidationErrorVO()

        return try {

            val expression = builder { PersistentServiceCredits::linearId.equal(valueContractTransactionVO.serviceCreditId) }

            val qryCriteria = QueryCriteria.VaultCustomQueryCriteria(expression)

            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)

            val vaultState = rpcOps.vaultQueryBy<CreateServiceCreditState>(qryCriteria.and(qryCriteriaUnconsumed)).states.singleOrNull()

            val serviceCredit = vaultState?.state?.data?.serviceCreditVO

            var flowHandle:FlowProgressHandle<SignedTransaction>

            var result:SignedTransaction?=null

            //0 AUV
            if(serviceCredit!!.serviceCreditCommitted)
                isBeyondCommitted(valueContractTransactionVO)

            if (null != serviceCredit) {

                //0 AUV
                if(!serviceCredit.serviceCreditCommitted)
                {
                    serviceCredit.status="Approved"
                }

                if (serviceCredit.status == "Approved") {

                    //Planned Type
                    //If the VCT type is Planned it will call the ValueContractInitiator Flow else it will call ImplementVCT flow
                    if (!valueContractTransactionVO.isimplemented) {
                       flowHandle = rpcOps.startTrackedFlow(::ValueContractInitiator, valueContractTransactionVO,tacticalauthorizer, operationalCustomer,counterParties)

                       flowHandle.progress.subscribe { println(">> $it") }

                        result=flowHandle.returnValue.getOrThrow()
                    }
                    //Implementation Type

                    else if (valueContractTransactionVO.isimplemented) {
                        //Iteration 4 remove the if condition
                            val validate = validateImplementation(valueContractTransactionVO)
                            if (validate)
                            {
                                flowHandle = rpcOps.startTrackedFlow(::RevisedValueContractApprover, valueContractTransactionVO,tacticalauthorizer, operationalCustomer, counterParties)
                               flowHandle.progress.subscribe { println(">> $it") }
                                result=flowHandle.returnValue.getOrThrow()
                            }
                            else
                            {
                                validationErrorVO.error="Planned VCT must be Approved"
                                return Response.ok(validationErrorVO, MediaType.APPLICATION_JSON).build()
                            }
                    }
                    /*else
               {
                   return Response.status(BAD_REQUEST).entity("VCT Type not mentioned\n").build()
               }*/
                    // Extract the IOUState StateAndRefs from the vault.

                 // var result=flowHandle.returnValue.getOrThrow()
                    var resultState= result!!.tx.outputs.single().data as ValueContractTransactionState
                    var resultValueContract=resultState.valueContractTransactionVO
                    resultValueContract.transactionID=result.id.toString()
                    val updatedVO = vctUpdatedComment(resultValueContract)
                    Response.ok(updatedVO, MediaType.APPLICATION_JSON).build()

                   /* val iouStateAndRefs = rpcOps.vaultQueryBy<ValueContractTransactionState>().states

                    // Map each StateAndRef to its IOUState.

                    val iouStates = iouStateAndRefs.map { it.state.data.valueContractTransactionVO }

                    val updatedVO= vctUpdatedComment(iouStates.last())

                    Response.ok(updatedVO, MediaType.APPLICATION_JSON).build()*/

                }

                else {
                    validationErrorVO.error="AUV needs to be Approved by Customer."
                    return Response.ok(validationErrorVO, MediaType.APPLICATION_JSON).build()
                }
            } else {
                validationErrorVO.error="This AUV already consumed."
                return Response.ok(validationErrorVO, MediaType.APPLICATION_JSON).build()

            }

        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity("Implementation Workflow Failed").build()
        }

    }


    /**
     * Initiates a flow to Authorize value contract transaction for respective service credit Id which is from create VCT.

     * Once finishes the Authorization, it ll create new value contract transaction Id for Approve the VCT.

     * the InitiatorCognizant, the AuthorizerCognizant and the OperationalCustomer  will be able to see it when calling /api/valueArticulation/ValueContract on their respective nodes.

     * This end-point takes a Party name parameter as part of the path. If the serving node can't find the other party
    in its network map cache, it will return an HTTP bad request.

     * The flow is invoked asynchronously. It returns a future when the flow's call() method returns.
     */

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("authorize-ValueContractTransaction")
    fun authorizeValueContractTransaction(@QueryParam("authorizer")authorizers:String,valueContractTransactionVO : ValueContractTransactionVO): Response {
        if (valueContractTransactionVO.agreedServiceCredits <= 0) {
            return Response.status(BAD_REQUEST).entity("Query parameter 'serviceCredit' must be non-negative.\n").build()
        }

        val authorizer:Party
        val optional:Party


        val ctsinitiator=CordaX500Name("InitiatorCognizant","London","GB")
        val initiator=rpcOps.wellKnownPartyFromX500Name(ctsinitiator)?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsinitiator cannot be found.\n").build()

        val tactCustomer = CordaX500Name("TacticalCustomer", "Paris", "FR")

        val tacticalCustomer = rpcOps.wellKnownPartyFromX500Name(tactCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $tactCustomer cannot be found.\n").build()



        val ctsPrimaryAuthorizer = CordaX500Name("PrimaryAuthorizer", "New York", "US")

        val primaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsPrimaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsPrimaryAuthorizer cannot be found.\n").build()

        val ctsSecondaryAuthorizer = CordaX500Name("SecondaryAuthorizer", "New York", "US")

        val secondaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsSecondaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsSecondaryAuthorizer cannot be found.\n").build()

        if(authorizers.equals("PrimaryAuthorizer",ignoreCase = true))
        {
            authorizer=primaryauthorizer
            optional=secondaryauthorizer
        }
        else
        {
            authorizer=secondaryauthorizer
            optional=primaryauthorizer
        }
        val optCustomer = CordaX500Name("OperationalCustomer", "Paris", "FR")

        val operationalCustomer = rpcOps.wellKnownPartyFromX500Name(optCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $optCustomer cannot be found.\n").build()


        val stratCognizant = CordaX500Name("StrategicCognizant", "London", "GB")

        val strategicCognizant = rpcOps.wellKnownPartyFromX500Name(stratCognizant) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCognizant cannot be found.\n").build()

        val stratCustomer = CordaX500Name("StrategicCustomer", "Paris", "FR")

        val strategicCustomer = rpcOps.wellKnownPartyFromX500Name(stratCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCustomer cannot be found.\n").build()

        val counterParties= ArrayList<Party>()

        counterParties.add(strategicCognizant)

        counterParties.add(strategicCustomer)

        counterParties.add(tacticalCustomer)

        val tacticalauthorizer=ArrayList<Party>()
        tacticalauthorizer.add(authorizer)
        tacticalauthorizer.add(optional)



        return try {
            val flowHandle = rpcOps.startTrackedFlow(::ValueContractAuthorizer, valueContractTransactionVO,initiator, tacticalauthorizer ,operationalCustomer,counterParties)
            flowHandle.progress.subscribe { println(">> $it") }

           val result= flowHandle.returnValue.getOrThrow()
            // Extract the IOUState StateAndRefs from the vault.

            var resultState= result.tx.outputs.single().data as ValueContractTransactionState
            var resultValueContract=resultState.valueContractTransactionVO
            resultValueContract.transactionID=result.id.toString()
            val updatedVO = vctUpdatedComment(resultValueContract)
            Response.ok(updatedVO, MediaType.APPLICATION_JSON).build()

        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
    }

    /**
     * Initiates a flow to Approve value contract transaction for respective service credit Id which is from Authorize VCT.

     * Once finishes the Approval, it ll create new final value contract transaction Id for future.

     * the InitiatorCognizant, the AuthorizerCognizant and the OperationalCustomer  will be able to see it when calling /api/valueArticulation/ValueContract on their respective nodes.

     * This end-point takes a Party name parameter as part of the path. If the serving node can't find the other party
    in its network map cache, it will return an HTTP bad request.

     * The flow is invoked asynchronously. It returns a future when the flow's call() method returns.
     */


    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("approve-ValueContractTransaction")
    fun approveValueContractTransaction(valueContractTransactionVO : ValueContractTransactionVO ): Response {
        if (valueContractTransactionVO.agreedServiceCredits <= 0)
        {
            return Response.status(BAD_REQUEST).entity("Query parameter 'serviceCredit' must be non-negative.\n").build()
        }


        val ctsinitiator=CordaX500Name("InitiatorCognizant","London","GB")
        val initiator=rpcOps.wellKnownPartyFromX500Name(ctsinitiator)?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsinitiator cannot be found.\n").build()

        val ctsPrimaryAuthorizer = CordaX500Name("PrimaryAuthorizer", "New York", "US")

        val primaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsPrimaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsPrimaryAuthorizer cannot be found.\n").build()

        val ctsSecondaryAuthorizer = CordaX500Name("SecondaryAuthorizer", "New York", "US")

        val secondaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsSecondaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsSecondaryAuthorizer cannot be found.\n").build()

        val tactCustomer = CordaX500Name("TacticalCustomer", "Paris", "FR")

        val tacticalCustomer = rpcOps.wellKnownPartyFromX500Name(tactCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $tactCustomer cannot be found.\n").build()

        val optCustomer = CordaX500Name("OperationalCustomer", "Paris", "FR")

        val operationalCustomer = rpcOps.wellKnownPartyFromX500Name(optCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $optCustomer cannot be found.\n").build()

        val stratCognizant = CordaX500Name("StrategicCognizant", "London", "GB")

        val strategicCognizant = rpcOps.wellKnownPartyFromX500Name(stratCognizant) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCognizant cannot be found.\n").build()

        val stratCustomer = CordaX500Name("StrategicCustomer", "Paris", "FR")

        val strategicCustomer = rpcOps.wellKnownPartyFromX500Name(stratCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCustomer cannot be found.\n").build()

        val counterParties= ArrayList<Party>()

        counterParties.add(strategicCognizant)

        counterParties.add(strategicCustomer)

        counterParties.add(tacticalCustomer)

        val tacticalauthorizer=ArrayList<Party>()
        tacticalauthorizer.add(primaryauthorizer)
        tacticalauthorizer.add(secondaryauthorizer)


        return try {
            val flowHandle = rpcOps.startTrackedFlow(::ValueContractApprover, valueContractTransactionVO,initiator,tacticalauthorizer ,operationalCustomer,counterParties)
            flowHandle.progress.subscribe { println(">> $it") }

            val result=flowHandle.returnValue.getOrThrow()
            // Extract the IOUState StateAndRefs from the vault.
            var resultState= result.tx.outputs.single().data as ValueContractTransactionState
            var resultValueContract=resultState.valueContractTransactionVO
            resultValueContract.transactionID=result.id.toString()
            val updatedVO = vctUpdatedComment(resultValueContract)
            Response.ok(updatedVO, MediaType.APPLICATION_JSON).build()


        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
    }

    /**
     * Initiates a flow to revise  the excecuted vct between two parties.( Initiator cognizant and customer tactical group)
     *
     * Once the flow finishes it will have revised the Service Credit to ledger. Both the initiatorCognizant and the Customer will be able to
     * see it when calling /api/valueArticulation/revise-ValueContractTransaction on their respective nodes.
     *
     * This end-point takes the valueContractTransactionVO object as the parameter. If the serving node can't find the other party
     * in its network map cache, it will return an HTTP bad request.
     *
     * The flow is invoked asynchronously. It returns a future when the flow's call() method returns.
     */


    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("revise-ValueContractTransaction")
    fun reviseValueContractTransaction(valueContractTransactionVO : ValueContractTransactionVO ): Response {

        if (valueContractTransactionVO.agreedServiceCredits <= 0)
        {
            return Response.status(BAD_REQUEST).entity("Query parameter 'serviceCredit' must be non-negative.\n").build()
        }

        val ctsinitiator=CordaX500Name("InitiatorCognizant","London","GB")
        val initiator=rpcOps.wellKnownPartyFromX500Name(ctsinitiator)?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsinitiator cannot be found.\n").build()

        val ctsPrimaryAuthorizer = CordaX500Name("PrimaryAuthorizer", "New York", "US")

        val primaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsPrimaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsPrimaryAuthorizer cannot be found.\n").build()

        val ctsSecondaryAuthorizer = CordaX500Name("SecondaryAuthorizer", "New York", "US")

        val secondaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsSecondaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsSecondaryAuthorizer cannot be found.\n").build()


        val tactCustomer = CordaX500Name("TacticalCustomer", "Paris", "FR")

        val tacticalCustomer = rpcOps.wellKnownPartyFromX500Name(tactCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $tactCustomer cannot be found.\n").build()

        val optCustomer = CordaX500Name("OperationalCustomer", "Paris", "FR")

        val operationalCustomer = rpcOps.wellKnownPartyFromX500Name(optCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $optCustomer cannot be found.\n").build()

        val stratCognizant = CordaX500Name("StrategicCognizant", "London", "GB")

        val strategicCognizant = rpcOps.wellKnownPartyFromX500Name(stratCognizant) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCognizant cannot be found.\n").build()

        val stratCustomer = CordaX500Name("StrategicCustomer", "Paris", "FR")

        val strategicCustomer = rpcOps.wellKnownPartyFromX500Name(stratCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCustomer cannot be found.\n").build()

        val counterParties= ArrayList<Party>()

        counterParties.add(strategicCognizant)

        counterParties.add(strategicCustomer)

        counterParties.add(tacticalCustomer)

        val tacticalauthorizer=ArrayList<Party>()
        tacticalauthorizer.add(primaryauthorizer)
        tacticalauthorizer.add(secondaryauthorizer)


        return try {
            val flowHandle = rpcOps.startTrackedFlow(::RevisedValueContractApprover, valueContractTransactionVO,tacticalauthorizer,operationalCustomer,counterParties)
            flowHandle.progress.subscribe { println(">> $it") }

            val result=flowHandle.returnValue.getOrThrow()
            // Extract the IOUState StateAndRefs from the vault.
            var resultState= result.tx.outputs.single().data as ValueContractTransactionState
            var resultValueContract=resultState.valueContractTransactionVO
            resultValueContract.transactionID=result.id.toString()
            val updatedVO = vctUpdatedComment(resultValueContract)
            Response.ok(updatedVO, MediaType.APPLICATION_JSON).build()


        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }

    }

    /**
     * Initiates a flow to authorize a Service Credits between two parties.( SDD Cognizant and Customer)
     *
     * Once the flow finishes it will have written the Service Credit to ledger. Both the AuthorizerCognizant and the Customer will be able to
     * see it when calling /api/valueArticulation/serviceCredits on their respective nodes.
     *
     * This end-point takes a Party name parameter as part of the path. If the serving node can't find the other party
     * in its network map cache, it will return an HTTP bad request.
     *
     * The flow is invoked asynchronously. It returns a future when the flow's call() method returns.
     */

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("revise-serviceCredits")
    fun reviseServiceCredits(serviceCreditVO : ServiceCreditVO ): Response {
        // Business validation starts here
        // service credit validation
        if (serviceCreditVO.serviceCredit <= 0 && serviceCreditVO.serviceCredit >= 99999) {
            return Response.status(BAD_REQUEST).entity("Query parameter 'serviceCredit' must be non-negative or greater than 99999.\n").build()
        }

        // Status field validation
        serviceCreditVO.status=="Revised"

        // Business validation ends here


        val ctsPrimaryAuthorizer = CordaX500Name("PrimaryAuthorizer", "New York", "US")

        val primaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsPrimaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsPrimaryAuthorizer cannot be found.\n").build()

        val ctsSecondaryAuthorizer = CordaX500Name("SecondaryAuthorizer", "New York", "US")

        val secondaryauthorizer = rpcOps.wellKnownPartyFromX500Name(ctsSecondaryAuthorizer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $ctsSecondaryAuthorizer cannot be found.\n").build()

        val tactCustomer = CordaX500Name("TacticalCustomer", "Paris", "FR")

        val tacticalCustomer = rpcOps.wellKnownPartyFromX500Name(tactCustomer) ?:
                return Response.status(BAD_REQUEST).entity("Party named $tactCustomer cannot be found.\n").build()

        val stratCognizant = CordaX500Name("StrategicCognizant", "London", "GB")

        val strategicCognizant = rpcOps.wellKnownPartyFromX500Name(stratCognizant) ?:
                return Response.status(BAD_REQUEST).entity("Party named $stratCognizant cannot be found.\n").build()

        val tacticalauthorizer=ArrayList<Party>()
        tacticalauthorizer.add(primaryauthorizer)
        tacticalauthorizer.add(secondaryauthorizer)




        //Attachment code starts here
       /* val path = serviceCreditVO.attachmentPath
        if (serviceCreditVO.attachmentPath == null || serviceCreditVO.attachmentPath == "" || serviceCreditVO.attachmentPath == " ") {
            return Response.status(BAD_REQUEST).entity(" 'AttachmentPath' not exist").build()}

        val pathName = path!!.substringBeforeLast(".")
        val fileName = pathName.substringAfterLast("/")

        if (fileName == "" || fileName == " ") {
            return Response.status(BAD_REQUEST).entity(" 'File' not exist").build()
        }
        val attachmentInputStream: InputStream = File(serviceCreditVO.attachmentPath).inputStream()
        val attachmentHash = rpcOps.uploadAttachment(attachmentInputStream).toString()
        serviceCreditVO.attachment = attachmentHash*/
        return try {
            val flowHandle = rpcOps.startTrackedFlow(::RevisedInitiator, serviceCreditVO,tacticalauthorizer, tacticalCustomer,strategicCognizant)
            flowHandle.progress.subscribe { println(">> $it") }
            // Extract the IOUState StateAndRefs from the vault.
            var result=flowHandle.returnValue.getOrThrow()
            var resultState=result.tx.outputs.single().data as CreateServiceCreditState
            var resultServiceCredit=resultState.serviceCreditVO
            resultServiceCredit.transactionID=result.id.toString()
            val updatedVO = auvUpdatedComment(resultServiceCredit)
            Response.ok(updatedVO, MediaType.APPLICATION_JSON).build()
        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
        //Attachment code ends here
    }

    /**
     *It gets the input as list of Business Unit.

     *Queries and  returns the list of AUV and VCT for the respective Business Unit.

     *And set the updated balance Service Credits by calling getBalance with paramaters ServiceCredit and
    the  queryCriteria to query the vct's by ServiceCreditId

     */

    @GET
    @Path("getAll_AUV_VCT_byBU")
    @Produces(MediaType.APPLICATION_JSON)
    fun getAuvVctByBU(@QueryParam("BU") BU: List<String>): ArrayList<ServiceCreditVO>
    {
        var serviceCreditVO = ArrayList<ServiceCreditVO>(BU.size)

        for(i in BU.indices){

            val getAUV = builder { PersistentServiceCredits::businessUnit.equal(BU[i]) }
            val auvQryCriteria = QueryCriteria.VaultCustomQueryCriteria(getAUV)
            val auvServiceCreditStates = rpcOps.vaultQueryBy<CreateServiceCreditState>(auvQryCriteria).states
            val AUVStates = auvServiceCreditStates.map { it.state.data.serviceCreditVO }

            for (j in AUVStates.indices) {

                val auvServiceCredits = AUVStates[j].serviceCredit

                val getVCT = builder { PresisentValueContractTransaction::auvId.equal(AUVStates[j].auvId) }
                val vctQryCriteria = QueryCriteria.VaultCustomQueryCriteria(getVCT)

                val vctServiceCreditStates = rpcOps.vaultQueryBy<ValueContractTransactionState>(vctQryCriteria).states
                val VCTStates = vctServiceCreditStates.map { it.state.data.valueContractTransactionVO }

                AUVStates[j].balanceServiceCredits = getbalance(auvServiceCredits,vctQryCriteria);



                AUVStates[j].valueContractTransactionVO = VCTStates as ArrayList<ValueContractTransactionVO>;



            }

            serviceCreditVO.addAll(AUVStates as ArrayList<ServiceCreditVO>)
        }
        return  serviceCreditVO

    }

    /**
     *It gets the input as list of Project IDs.

     *Queries and  returns the list of AUV and VCT for the respective Project IDs.

     *And set the updated balance Service Credits by calling getBalance with paramaters ServiceCredit and
    the  queryCriteria to query the vct's by ServiceCreditId

     */


    @GET
    @Path("getAll_AUV_VCT_ByProjectId")
    @Produces(MediaType.APPLICATION_JSON)
    fun getProjectDetails(@QueryParam("projectId")projectId: List<String>) :ArrayList<ServiceCreditVO>{

        var valueContractTransactionVO = ArrayList<ServiceCreditVO>()


        for(i in  projectId.indices) {
            // Querying the Project Details from Service Credit table and VCT table

            val projectId= builder { PersistentServiceCredits::projectId.equal(projectId[i]) }
            val projectqryCriteria  = QueryCriteria.VaultCustomQueryCriteria(projectId)
            val auvvaultStateAndRef =rpcOps.vaultQueryBy<CreateServiceCreditState>(projectqryCriteria).states
            val  auvvaultState  = auvvaultStateAndRef.map {  it.state.data.serviceCreditVO }

            for (j in auvvaultState.indices){

                var auvServiceCredits = auvvaultState[j].serviceCredit
                // Querying the Service Credit from   ValueContractTransactionState Vault
                val serviceCreditId= builder { PresisentValueContractTransaction::auvId.equal(auvvaultState[j].auvId) }
                val serviceCreditIdqryCriteria = QueryCriteria.VaultCustomQueryCriteria(serviceCreditId)

                val allvctvaultStateAndRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(serviceCreditIdqryCriteria).states
                val allvctvaultState  = allvctvaultStateAndRef.map {  it.state.data.valueContractTransactionVO }

                auvvaultState[j].balanceServiceCredits = getbalance(auvServiceCredits,serviceCreditIdqryCriteria)
                auvvaultState[j].valueContractTransactionVO = allvctvaultState as ArrayList<ValueContractTransactionVO>

            }

            valueContractTransactionVO.addAll(auvvaultState as ArrayList<ServiceCreditVO>)

        }
        return valueContractTransactionVO

    }



    /**
     *It gets the input as list of Account name.

     *Queries and  returns the list of AUV and VCT for the respective Account name.

     *And set the updated balance Service Credits by calling getBalance with paramaters ServiceCredit and
    the  queryCriteria to query the vct's by ServiceCreditId

     */

    @GET
    @Path("getAll_AUV_VCT_ByAccount")
    @Produces(MediaType.APPLICATION_JSON)
    fun AccountDetails(@QueryParam("account") account : List<String>) : ArrayList<ServiceCreditVO> {

        val AUVandVCT = ArrayList<ServiceCreditVO>()



        for (i in account.indices) {

            val getAUV = builder { PersistentServiceCredits::accountName.equal(account[i]) }

            val auvQryCriteria = QueryCriteria.VaultCustomQueryCriteria(getAUV)
            val auvServiceCreditStates = rpcOps.vaultQueryBy<CreateServiceCreditState>(auvQryCriteria).states
            val AUVStates = auvServiceCreditStates.map { it.state.data.serviceCreditVO }

            for (j in AUVStates.indices) {

                val auvServiceCredits = AUVStates[j].serviceCredit
                val getVCT = builder { PresisentValueContractTransaction::auvId.equal(AUVStates[j].auvId) }
                val VCTQueryCriteria = QueryCriteria.VaultCustomQueryCriteria(getVCT)
                val VCTVaultStateAndRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(VCTQueryCriteria).states
                val VCTVaultState = VCTVaultStateAndRef.map { it.state.data.valueContractTransactionVO }



                AUVStates[j].balanceServiceCredits = getbalance(auvServiceCredits,VCTQueryCriteria);


                AUVStates[j].valueContractTransactionVO = VCTVaultState as ArrayList<ValueContractTransactionVO>
            }
            AUVandVCT.addAll(AUVStates)
        }
        return AUVandVCT

    }


    /**
     *It gets the input as list of Project ID.

     *Queries and  returns the list of VCT for the respective Project ID.

     */

    /*@GET
    @Path("getAll_AUV_ByProjectId")
    @Produces(MediaType.APPLICATION_JSON)
    fun GetAUVByProjectId(@QueryParam("isdashboard") isdashboard:Boolean, @QueryParam("projectId") projectId: List<Int>): DashboardVO
    {

        var dashboard=DashboardVO()


        var AllAUV= getAUV(false, Collections.emptyList())


        if(!isdashboard &&!projectId.isEmpty())
        {
          dashboard.serviceCreditVO.addAll(getAUV(true,projectId))

        }
        else if(isdashboard)
        {
            dashboard.auvCount=AllAUV.size

            for(i in AllAUV.indices)
            {
                if(AllAUV[i].status.equals("Approved",ignoreCase = true))
                    dashboard.totalServiceCreditsCommitted+=AllAUV[i].serviceCredit


            }

            if(projectId.isEmpty())
            {

                var vct=getVCT(false, Collections.emptyList())

                for(i in AllAUV.indices)
                {
                    if(AllAUV[i].status.equals("Approved",ignoreCase = true))
                        dashboard.serviceCreditsCommitted+=AllAUV[i].serviceCredit


                }
                for(j in vct.indices)
                {
                    when
                    {

                        vct[j].status == "Authorized" -> dashboard.serviceCreditsPending += vct[j].agreedServiceCredits
                        vct[j].status == "Submitted" -> dashboard.serviceCreditsPending += vct[j].agreedServiceCredits
                        vct[j].status == "Approved" -> dashboard.serviceCreditsApproved += vct[j].agreedServiceCredits
                        vct[j].status == "Rejected" -> dashboard.serviceCreditsRejected += vct[j].agreedServiceCredits
                    }
                }
            }
            else
            {


                var list=getAUV(true,projectId)
                var vct=getVCT(true, projectId)


                for(i in list.indices)
                {
                    if(list[i].status.equals("Approved",ignoreCase = true))
                        dashboard.serviceCreditsCommitted+=list[i].serviceCredit

                }
                for(j in vct.indices)
                {
                    when
                    {

                        vct[j].status == "Authorized" -> dashboard.serviceCreditsPending += vct[j].agreedServiceCredits
                        vct[j].status == "Submitted" -> dashboard.serviceCreditsPending += vct[j].agreedServiceCredits
                        vct[j].status == "Approved" -> dashboard.serviceCreditsApproved += vct[j].agreedServiceCredits
                        vct[j].status == "Rejected" -> dashboard.serviceCreditsRejected += vct[j].agreedServiceCredits
                    }
                }
            }

        }
        return dashboard

    }
*/
    @GET
    @Path("getAll_AUV_ByProjectId")
    @Produces(MediaType.APPLICATION_JSON)
    fun GetAUVByProjectId(@QueryParam("projectId") projectId: List<Int>):  ArrayList<ServiceCreditVO>
    {
        val AUV = ArrayList<ServiceCreditVO>()

        for (i in projectId.indices)
        {

            val getAUV = builder { PersistentServiceCredits::projectId.equal(projectId[i]) }

            val auvQryCriteria = QueryCriteria.VaultCustomQueryCriteria(getAUV)

            val VCTVaultStateAndRef  = rpcOps.vaultQueryBy<CreateServiceCreditState>(auvQryCriteria).states

            val AUVStates = VCTVaultStateAndRef.map { it.state.data.serviceCreditVO}

            AUV.addAll(AUVStates)
        }

        return AUV
    }


    /**

     *It gets the input as list of Project ID.

     *Queries and  returns the list of VCT for the respective Project ID.

     */
    @GET
    @Path("getAll_VCT_ByProjectId")
    @Produces(MediaType.APPLICATION_JSON)
    fun GetVCTByProjectid(@QueryParam("projectId") projectId : List<Int>) : ArrayList<ValueContractTransactionVO>
    {

        val VCT=ArrayList<ValueContractTransactionVO>()

        println("VCT==========="+VCT)

        for (i in projectId.indices) {
            //val VCT = ArrayList<ValueContractTransactionVO>()

            val getVCT = builder { PresisentValueContractTransaction::projectId.equal(projectId[i]) }

            val vctQryCriteria = QueryCriteria.VaultCustomQueryCriteria(getVCT)

            val vctStateandRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(vctQryCriteria).states

            val VCTStates = vctStateandRef.map { it.state.data.valueContractTransactionVO }

            for(j in VCTStates.indices)
            {
                VCT.add(vctUpdatedComment(VCTStates[j]))
            }


           // VCT.addAll(VCTStates )
        }

        return VCT
    }


    /**
     *It gets the input as list of AUVID.

     *Queries and  returns the list of VCT for the respective AUVID.

     */


    @GET
    @Path("getAll_VCT_ByAUVId")
    @Produces(MediaType.APPLICATION_JSON)
    fun getAll_VCT_byAUVId(@QueryParam("auvId") auvId : List<String>) : ArrayList<ValueContractTransactionVO>
    {

        val VCT = ArrayList<ValueContractTransactionVO>()

        for (i in auvId.indices) {

            val getVCT = builder { PresisentValueContractTransaction::auvId.equal(auvId[i]) }

            val vctQryCriteria = QueryCriteria.VaultCustomQueryCriteria(getVCT)

            val vctStateandRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(vctQryCriteria).states

            val VCTStates = vctStateandRef.map { it.state.data.valueContractTransactionVO }

            VCT.addAll(VCTStates )
        }

        return VCT
    }


    /*@GET
    @Path("performanceReportByProjectId")
    @Produces(MediaType.APPLICATION_JSON)
    fun performanceReportByProjectId(@QueryParam("projectId") projectId: List<Int>, @QueryParam("report")report:String, @QueryParam("subCategory")subCategory:String): ReportCategoryVO
    {
        val reportGenApi = ReportGenApi()

        val reportCategoryVO=ReportCategoryVO()

        val allVCTStates = ArrayList<ValueContractTransactionVO>()

        if(allVCTStates.isEmpty())
        {

            for (i in projectId.indices) {


                val getVCT = builder { PresisentValueContractTransaction::projectId.equal(projectId[i]) }
                val vctQueryCriteria = QueryCriteria.VaultCustomQueryCriteria(getVCT)

                val vctapprovedCriteria = builder { PresisentValueContractTransaction::status.equal("Approved") }
                val approvedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctapprovedCriteria)

                val vctimplementedCriteria = builder { PresisentValueContractTransaction::isimplemented.equal(true) }
                val implementedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctimplementedCriteria)

                val vctStateandRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(vctQueryCriteria.and(approvedCriteria.and(implementedCriteria))).states
                val vctStates = vctStateandRef.map { it.state.data.valueContractTransactionVO }

                allVCTStates.addAll(vctStates)


            }
        }



        if(report.equals("yes",ignoreCase = true) && subCategory.equals("LeverCategory",ignoreCase = true))
        {
            val leverCategoryVOList= reportGenApi.leverCategory_Project(allVCTStates)

             reportCategoryVO.leverCategoryVO=leverCategoryVOList
            return reportCategoryVO
            //Response.ok(leverCategoryVOList, MediaType.APPLICATION_JSON).build()
        }
        else if (report.equals("Yes", ignoreCase = true) && subCategory.equals("ValueCategory", ignoreCase = true))
        {
            val valueCategoryVOList= reportGenApi.valueCategory_Project(allVCTStates)
            reportCategoryVO.valueCategoryVO= valueCategoryVOList
            return reportCategoryVO
            //Response.ok(valueCategoryVOList, MediaType.APPLICATION_JSON).build()
        }
        else
        {
            val themeCategoryVOList= reportGenApi.theme_Project(allVCTStates)
            reportCategoryVO.themeCategoryVO=themeCategoryVOList
            return reportCategoryVO
        }

    }

    @GET
    @Path("performanceReportByBU")
    @Produces(MediaType.APPLICATION_JSON)
    fun performanceReportByBU(@QueryParam("bu") BU: List<String>, @QueryParam("report")report:String, @QueryParam("subCategory")subCategory:String): ReportCategoryVO
    {
        val reportGenApi = ReportGenApi()

        val reportCategoryVO=ReportCategoryVO()

        val allVCTStates = ArrayList<ValueContractTransactionVO>()

        if(allVCTStates.isEmpty()) {

            for (i in BU.indices) {


                val getAUV = builder { PersistentServiceCredits::businessUnit.equal(BU[i]) }
                val auvQryCriteria = QueryCriteria.VaultCustomQueryCriteria(getAUV)
                val auvServiceCreditStates = rpcOps.vaultQueryBy<CreateServiceCreditState>(auvQryCriteria).states
                val AUVStates = auvServiceCreditStates.map { it.state.data.serviceCreditVO }


                for (i in AUVStates.indices) {



                    val getVCT = builder { PresisentValueContractTransaction::serviceCreditId.equal(AUVStates[i].serviceCreditId) }
                    val vctQueryCriteria = QueryCriteria.VaultCustomQueryCriteria(getVCT)

                    val vctapprovedCriteria = builder { PresisentValueContractTransaction::status.equal("Approved") }
                    val approvedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctapprovedCriteria)

                    val vctimplementedCriteria = builder { PresisentValueContractTransaction::isimplemented.equal(true) }
                    val implementedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctimplementedCriteria)

                    val vctStateandRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(vctQueryCriteria.and(approvedCriteria.and(implementedCriteria))).states
                    val vctStates = vctStateandRef.map { it.state.data.valueContractTransactionVO }



                    allVCTStates.addAll(vctStates)


                }
            }
        }

        if(report.equals("Yes", ignoreCase = true) && subCategory.equals("LeverCategory", ignoreCase = true))
        {
            val leverCategoryVOList= reportGenApi.leverCategory_Project(allVCTStates)
            reportCategoryVO.leverCategoryVO=leverCategoryVOList
            return reportCategoryVO
            //Response.ok(leverCategoryVOList, MediaType.APPLICATION_JSON).build()
        }
        else if (report.equals("Yes", ignoreCase = true) && subCategory.equals("ValueCategory", ignoreCase = true))
        {
            val valueCategoryVOList= reportGenApi.valueCategory_Project(allVCTStates)
            reportCategoryVO.valueCategoryVO= valueCategoryVOList
            return reportCategoryVO
            //Response.ok(valueCategoryVOList, MediaType.APPLICATION_JSON).build()
        }
        else
        {
            val themeCategoryVOList= reportGenApi.theme_Project(allVCTStates)
            reportCategoryVO.themeCategoryVO=themeCategoryVOList
            return reportCategoryVO
        }

    }


    @GET
    @Path("performanceReportByAccount")
    @Produces(MediaType.APPLICATION_JSON)
    fun performanceReportByAccount(@QueryParam("account") account: List<String>, @QueryParam("report")report:String, @QueryParam("subCategory")subCategory:String): ReportCategoryVO {
        val reportGenApi = ReportGenApi()

        val reportCategoryVO=ReportCategoryVO()

        val allVCTStates = ArrayList<ValueContractTransactionVO>()

        if(allVCTStates.isEmpty())
        {

            for (i in account.indices) {

                val getAUV = builder { PersistentServiceCredits::accountName.equal(account[i]) }
                val auvQryCriteria = QueryCriteria.VaultCustomQueryCriteria(getAUV)
                val auvServiceCreditStates = rpcOps.vaultQueryBy<CreateServiceCreditState>(auvQryCriteria).states
                val AUVStates = auvServiceCreditStates.map { it.state.data.serviceCreditVO }

                for (i in AUVStates.indices) {


                    val getVCT = builder { PresisentValueContractTransaction::serviceCreditId.equal(AUVStates[i].serviceCreditId) }
                    val vctQueryCriteria = QueryCriteria.VaultCustomQueryCriteria(getVCT)

                    val vctapprovedCriteria = builder { PresisentValueContractTransaction::status.equal("Approved") }
                    val approvedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctapprovedCriteria)

                    val vctimplementedCriteria = builder { PresisentValueContractTransaction::isimplemented.equal(true) }
                    val implementedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctimplementedCriteria)

                    val vctStateandRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(vctQueryCriteria.and(approvedCriteria.and(implementedCriteria))).states
                    val vctStates = vctStateandRef.map { it.state.data.valueContractTransactionVO }

                    allVCTStates.addAll(vctStates)


                }
            }
        }

        if(report.equals("Yes", ignoreCase = true) && subCategory.equals("LeverCategory", ignoreCase = true))
        {
            val leverCategoryVOList= reportGenApi.leverCategory_Project(allVCTStates)
            reportCategoryVO.leverCategoryVO=leverCategoryVOList
            return reportCategoryVO
            //Response.ok(leverCategoryVOList, MediaType.APPLICATION_JSON).build()
        }
        else if (report.equals("Yes", ignoreCase = true) && subCategory.equals("ValueCategory", ignoreCase = true))
        {
            val valueCategoryVOList= reportGenApi.valueCategory_Project(allVCTStates)
            reportCategoryVO.valueCategoryVO= valueCategoryVOList
            return reportCategoryVO
            //Response.ok(valueCategoryVOList, MediaType.APPLICATION_JSON).build()
        }
        else
        {
            val themeCategoryVOList= reportGenApi.theme_Project(allVCTStates)
            reportCategoryVO.themeCategoryVO=themeCategoryVOList
            return reportCategoryVO
        }

    }
*/
    //This functions queries unconsumed state for the planned VCT and checks the VCTType and Status for validation
    //This function validates  whether it is planned and approved before implemented

    @GET
    @Path("getDashboardDetails")
    @Produces(MediaType.APPLICATION_JSON)
    fun getDashboardDetails(@QueryParam("role") role: String, @QueryParam("param")param:List<String>,@QueryParam("all")all:Boolean):DashboardVO
    {

        val reportGenApi = ReportGenApi()

        var AllAUV= getAUV()

        var AllVCT=getVCT()

        return reportGenApi.getDetails(AllAUV,AllVCT,role,param,all)
    }

    @GET
    @Path("getReportDetails")
    @Produces(MediaType.APPLICATION_JSON)
    fun getReportDetails(@QueryParam("role")role:String, @QueryParam("category")category:String, @QueryParam("param")param:List<String>):ValueCategory
    {
        val reportGenApi = ReportGenApi()

        var allAUV= getAUV()

        var allVCT=getVCT()

        return reportGenApi.getreportDetails(allAUV,allVCT,role,param)

    }



    @GET
    @Path("getAdditionalGraph")
    @Produces(MediaType.APPLICATION_JSON)
    fun getAdditionalGraph(@QueryParam("role") role: String, @QueryParam("param")param:List<String>):AdditionalGraphVO
    {
        val reportGenApi = ReportGenApi()

        var allAUV= getAUV()

        var allVCT=getVCT()

        return reportGenApi.getAdditionalGraphDetails(allAUV,allVCT,role,param)

    }

    @GET
    @Path("getDashboardGraph")
    @Produces(MediaType.APPLICATION_JSON)
    fun getDashboardGraph(@QueryParam("role") role: String, @QueryParam("param")param:List<String>):ValueCategory
    {
        val reportGenApi = ReportGenApi()

        var allAUV= getAUV()

        var allVCT=getVCT()

        return reportGenApi.getDashboardGraph(allAUV,allVCT,role,param)
    }




    private fun getAUV():ArrayList<ServiceCreditVO>
    {
        val iouStateAndRefs = rpcOps.vaultQueryBy<CreateServiceCreditState>().states

        val iouStates = iouStateAndRefs.map { it.state.data.serviceCreditVO }

        var list=ArrayList<ServiceCreditVO>()

        for(i in iouStates.indices)
        {
            list.add(auvUpdatedComment(iouStates[i]))
        }
        return list
    }

    private fun getVCT():ArrayList<ValueContractTransactionVO>
    {
        //var vctList=ArrayList<ValueContractTransactionVO>()

        val iouStateAndRefs = rpcOps.vaultQueryBy<ValueContractTransactionState>().states

        val iouStates = iouStateAndRefs.map { it.state.data.valueContractTransactionVO }as ArrayList<ValueContractTransactionVO>

        for(i in iouStateAndRefs.indices)
        {
            if(iouStateAndRefs[i].state.data.valueContractTransactionVO.valueContractTransactionId==iouStates[i].valueContractTransactionId)
            {
                iouStates[i].transactionID=iouStateAndRefs[i].ref.txhash.toString()
            }
        }

           /* for (j in iouStates.indices)
            {

                if (iouStates[j].isimplemented)
                {
                    vctList.add(iouStates[j])
                }
            }
            return vctList*/
        return iouStates
    }

    private fun validateImplementation(valueContractTransactionVO: ValueContractTransactionVO): Boolean {
        //included a try in iteration 4
        try {
            val expression = builder { PresisentValueContractTransaction::linearId.equal(valueContractTransactionVO.valueContractTransactionId) }
            val qryCriteria = QueryCriteria.VaultCustomQueryCriteria(expression)


            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
            val vaultState = rpcOps.vaultQueryBy<ValueContractTransactionState>(qryCriteria.and(qryCriteriaUnconsumed)).states.singleOrNull()


            val VCTtype = vaultState?.state?.data?.valueContractTransactionVO?.isimplemented
            val VCTStatus = vaultState?.state?.data?.valueContractTransactionVO?.status


            if((!VCTtype!! && VCTStatus=="Approved")){
                return true
            }
        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            return false
        }
        return false

    }

    /**
     * This function queries all the approved value contract transactions for one AUV from H2 Table
    and sends the data to BalanceCalculation function in  ValueArticulationValidation() method

     *Input : Agreed upon ServiceCredit and the  queryCriteria to query the vct's by ServiceCreditId
    Output Calculated Balance.
     */


    private fun getbalance(auvServiceCredits: Int, serviceCreditIdqryCriteria: QueryCriteria.VaultCustomQueryCriteria<PresisentValueContractTransaction>):Int  {

        val approved= builder { PresisentValueContractTransaction::status.equal("Approved")}
        val approvedqryCriteria = QueryCriteria.VaultCustomQueryCriteria(approved)

        // Checked whether it is implemented
        val implemented= builder { PresisentValueContractTransaction::isimplemented.equal(true) }
        val implementCriteria = QueryCriteria.VaultCustomQueryCriteria(implemented)

        // Extract the StateAndRefs from the vault.
        val vctvaultStateAndRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(serviceCreditIdqryCriteria.and(approvedqryCriteria).and(implementCriteria)).states

        val vctvaultState  = vctvaultStateAndRef.map {  it.state.data.valueContractTransactionVO }
        var validationObj = ValueArticulationValidation()
        var balanceServiceCredits = validationObj.getbalance(auvServiceCredits,vctvaultState)

        return balanceServiceCredits;

    }

    private fun isBeyondCommitted (valueContractTransactionVO:ValueContractTransactionVO): Boolean {

        // checking if the service credits submitted is beyond committed

        val auvexpression = builder { PersistentServiceCredits::auvId.equal(valueContractTransactionVO.auvId) }
        val auvqryCriteria = QueryCriteria.VaultCustomQueryCriteria(auvexpression)

        val auvunconsumedqryCriteria = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)

        val auvvaultStateAndRef = rpcOps.vaultQueryBy<CreateServiceCreditState>(auvqryCriteria.and(auvunconsumedqryCriteria)).states.singleOrNull()
        val baseservicecredits  = auvvaultStateAndRef!!.state.data.serviceCreditVO.serviceCredit

        val vctexpression= builder { PresisentValueContractTransaction::auvId.equal(valueContractTransactionVO.auvId)  } //Revise AUV Toniya
        val vctqryCriteria = QueryCriteria.VaultCustomQueryCriteria(vctexpression)

        val auvbalance= getbalance(baseservicecredits,vctqryCriteria)
        val balance = auvbalance-valueContractTransactionVO.agreedServiceCredits
        if(balance<0){
            valueContractTransactionVO.isbeyondcommited=true

        }
        return false
    }


    //Listing the comment as log

    private fun auvUpdatedComment(serviceCreditVO: ServiceCreditVO):ServiceCreditVO
    {
        val splitedinternalcommentList=ArrayList<String>()

        val splitedcommentList=ArrayList<String>()

        val splitedinternalcomment = serviceCreditVO.internalComments!!.split((";").toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()

        splitedinternalcomment.reverse()


        for(temp in splitedinternalcomment)
            splitedinternalcommentList.add(temp)

        serviceCreditVO.internalcommentList=splitedinternalcommentList

        val splitedcomment = serviceCreditVO.comments!!.split((";").toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()

        splitedcomment.reverse()

        for(temp in splitedcomment)
            splitedcommentList.add(temp)

        serviceCreditVO.commentList=splitedcommentList


        return serviceCreditVO
    }

    private fun vctUpdatedComment(valueContractTransactionVO: ValueContractTransactionVO):ValueContractTransactionVO
    {
        val splitedinternalcommentList=ArrayList<String>()

        val splitedcustomercommentList=ArrayList<String>()

        val splitedinternalcomment = valueContractTransactionVO.internalComments!!.split((";").toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()

        splitedinternalcomment.reverse()


        for(temp in splitedinternalcomment)
            splitedinternalcommentList.add(temp)

        valueContractTransactionVO.internalcommentList=splitedinternalcommentList

        val splitedcustomercomment = valueContractTransactionVO.customerComments!!.split((";").toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()

        splitedcustomercomment.reverse()

        for(temp in splitedcustomercomment)
            splitedcustomercommentList.add(temp)

        valueContractTransactionVO.customercommentList=splitedcustomercommentList


        return valueContractTransactionVO
    }





/*    @GET
    @Path("performanceReport_VC_byProjectId")
    fun performanceReport_VC_byProjectId(@QueryParam("projectId") projectId: List<Int>): Response
    {
        val reportGenApi = ReportGenApi()
        val allVCTStates = ArrayList<ValueContractTransactionVO>()

        for (i in projectId.indices) {

            val getVCT = builder { PresisentValueContractTransaction::projectId.equal(projectId[i]) }
            val vctQueryCriteria = QueryCriteria.VaultCustomQueryCriteria(getVCT)

            val vctapprovedCriteria= builder { PresisentValueContractTransaction::status.equal("Approved") }
            val approvedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctapprovedCriteria)

            val vctimplementedCriteria= builder { PresisentValueContractTransaction::isimplemented.equal(true) }
            val implementedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctimplementedCriteria)

            val vctStateandRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(vctQueryCriteria.and(approvedCriteria.and(implementedCriteria))).states
            val vctStates = vctStateandRef.map { it.state.data.valueContractTransactionVO }

            allVCTStates.addAll(vctStates)

        }
        val valueCategoryVOList= reportGenApi.valueCategory_Project(allVCTStates)

        return Response.ok(valueCategoryVOList, MediaType.APPLICATION_JSON).build()
    }


    @GET
    @Path("performanceReport_LC_byProjectId")
    fun performanceReport_LC_byProjectId(@QueryParam("projectId") projectId: List<Int>): Response
    {
        val reportGenApi = ReportGenApi()
        val allVCTStates = ArrayList<ValueContractTransactionVO>()

        for (i in projectId.indices) {

            val getVCT = builder { PresisentValueContractTransaction::projectId.equal(projectId[i]) }
            val vctQueryCriteria = QueryCriteria.VaultCustomQueryCriteria(getVCT)

            val vctapprovedCriteria= builder { PresisentValueContractTransaction::status.equal("Approved") }
            val approvedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctapprovedCriteria)

            val vctimplementedCriteria= builder { PresisentValueContractTransaction::isimplemented.equal(true) }
            val implementedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctimplementedCriteria)

            val vctStateandRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(vctQueryCriteria.and(approvedCriteria.and(implementedCriteria))).states
            val vctStates = vctStateandRef.map { it.state.data.valueContractTransactionVO }

            allVCTStates.addAll(vctStates)

        }
        val valueCategoryVOList= reportGenApi.leverCategory_Project(allVCTStates)

        return Response.ok(valueCategoryVOList, MediaType.APPLICATION_JSON).build()
    }

    @GET
    @Path("performanceReport_Theme_byProjectId")
    fun performanceReport_Theme_byProjectId(@QueryParam("projectId") projectId: List<Int>): Response
    {
        val reportGenApi = ReportGenApi()
        val allVCTStates = ArrayList<ValueContractTransactionVO>()

        for (i in projectId.indices) {

            val getVCT = builder { PresisentValueContractTransaction::projectId.equal(projectId[i]) }
            val vctQueryCriteria = QueryCriteria.VaultCustomQueryCriteria(getVCT)

            val vctapprovedCriteria= builder { PresisentValueContractTransaction::status.equal("Approved") }
            val approvedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctapprovedCriteria)

            val vctimplementedCriteria= builder { PresisentValueContractTransaction::isimplemented.equal(true) }
            val implementedCriteria = QueryCriteria.VaultCustomQueryCriteria(vctimplementedCriteria)

            val vctStateandRef = rpcOps.vaultQueryBy<ValueContractTransactionState>(vctQueryCriteria.and(approvedCriteria.and(implementedCriteria))).states
            val vctStates = vctStateandRef.map { it.state.data.valueContractTransactionVO }

            allVCTStates.addAll(vctStates)

        }
        val valueCategoryVOList= reportGenApi.theme_Project(allVCTStates)

        return Response.ok(valueCategoryVOList, MediaType.APPLICATION_JSON).build()
    }*/
}


