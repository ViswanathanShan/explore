package com.valuemanagement.model

import net.corda.core.serialization.CordaSerializable

@CordaSerializable
class LeverCategoryVO {

    var csi: Int = 0

    var transformation: Int = 0

    var automation: Int = 0

    var eliminate: Int = 0

    var industrialization: Int = 0

    var transformationSynergize:Int = 0

    var projectId: Int = 0

    var year: Int = 0

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as LeverCategoryVO

        if (projectId != other.projectId) return false
        if (year != other.year) return false
        if (csi != other.csi) return false
        if (transformation != other.transformation) return false
        if (automation != other.automation) return false
        if (eliminate != other.eliminate) return false
        if (industrialization != other.industrialization) return false
        if (transformationSynergize != other.transformationSynergize) return false

        return true
    }

    override fun hashCode(): Int {
        var result = projectId
        result = 31 * result + year
        result = 31 * result + csi
        result = 31 * result + transformation
        result = 31 * result + automation
        result = 31 * result + eliminate
        result = 31 * result + industrialization
        result = 31 * result + transformationSynergize
        return result
    }

    override fun toString(): String {
        return "LeverCategoryVO(projectId=$projectId, year=$year, csi=$csi, transformation=$transformation, automation=$automation, eliminate=$eliminate, industrialization=$industrialization, transformationSynergize=$transformationSynergize)"
    }
}