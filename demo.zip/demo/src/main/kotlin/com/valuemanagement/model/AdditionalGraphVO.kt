package com.valuemanagement.model

import net.corda.core.serialization.CordaSerializable

@CordaSerializable
class AdditionalGraphVO {

    var StackedBar=ArrayList<StackedBar>()
    var TreeMap=ArrayList<TreeMap>()
    var percent:Double=0.0
    var overAllServiceCredits=ArrayList<Overall>()

}
class StackedBar
{
    var projectid:String?=null
    var approved:Int=0
    var rejected:Int=0
    var pending:Int=0
}

class Overall
{
    var approved:Int=0
    var rejected:Int=0
    var pending:Int=0
}