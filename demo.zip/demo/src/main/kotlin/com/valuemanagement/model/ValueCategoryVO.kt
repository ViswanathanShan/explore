package com.valuemanagement.model

import net.corda.core.serialization.CordaSerializable

@CordaSerializable
class ValueCategoryVO {

    var valueRetention: Int = 0

    var valuePremium: Int = 0

    var valueAddition: Int =0

    var projectId: Int = 0

    var year: Int = 0



    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as ValueCategoryVO

        if (valueRetention != other.valueRetention) return false
        if (valuePremium != other.valuePremium) return false
        if (valueAddition != other.valueAddition) return false
        if (projectId != other.projectId) return false
        //if (year != other.year) return false

        return true
    }

    override fun hashCode(): Int {
        var result = valueRetention
        result = 31 * result + valuePremium
        result = 31 * result + valueAddition
        result = 31 * result + projectId
        //result = 31 * result + year
        return result
    }

    override fun toString(): String {
        return "ValueCategoryVO(valueRetention=$valueRetention, valuePremium=$valuePremium, valueAddition=$valueAddition, projectId=$projectId, year=$year)"
    }

}
