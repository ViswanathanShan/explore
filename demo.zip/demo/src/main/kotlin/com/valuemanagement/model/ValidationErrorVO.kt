package com.valuemanagement.model

import net.corda.core.serialization.CordaSerializable

@CordaSerializable
class ValidationErrorVO {

    var error:String?=null

}