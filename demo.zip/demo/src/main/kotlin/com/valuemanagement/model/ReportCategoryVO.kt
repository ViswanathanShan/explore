package com.valuemanagement.model

import net.corda.core.serialization.CordaSerializable

@CordaSerializable
class ReportCategoryVO {

    var leverCategoryVO=ArrayList<LeverCategoryVO>()

    var valueCategoryVO=ArrayList<ValueCategoryVO>()

    var themeCategoryVO=ArrayList<ThemeCategoryVO>()

}