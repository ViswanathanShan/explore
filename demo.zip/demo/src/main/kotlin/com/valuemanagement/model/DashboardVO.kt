package com.valuemanagement.model

import net.corda.core.serialization.CordaSerializable

@CordaSerializable
class DashboardVO {
    var auvCount:Int=0
    var approvedAuvCount:Int=0
    var pendingAuvCount:Int=0
    var approvedTotalServiceCreditsCommitted:Int=0
    var pendingTotalServiceCreditsCommitted:Int=0
    var serviceCreditsCommitted:Int=0
    var plannedServiceCreditsApproved:Int=0
    var plannedServiceCreditsPending:Int=0
    var plannedServiceCreditsRejected:Int=0
    var implementedServiceCreditsApproved:Int=0
    var implementedServiceCreditsPending:Int=0
    var implementedServiceCreditsRejected:Int=0
    var serviceCreditVO=ArrayList<ServiceCreditVO>()
    var projectList=ArrayList<Int>()

}
