package com.valuemanagement.model

import net.corda.core.serialization.CordaSerializable

@CordaSerializable
class ValueCategory {

    var overAllCategory=ArrayList<ProjectDetails>()
    var overAllServiceCredits=ArrayList<Category>()
    var treeMap=ArrayList<TreeMap>()
    var name:String="cts"
    var children=ArrayList<BU>()
}
class ProjectDetails
{
    var projectID:String? = null
    var projectName:String?=null
    var totalServiceCredits:Int=0
    var valueCategory=ArrayList<Category>()
}
class Category
{

    var Premium:Int=0
    var Addition:Int=0
    var Retention:Int=0
}
class TreeMap
{
    var projectName:String?=null
    var status:String?=null
    var value:Int=0
    var transactionID:String?=null
    var initiator:String?=null
    var authorizer:String?=null
    var approver:String?=null
}
class BU
{
    var name:String?=null
    var children=ArrayList<Account>()
}
class Account
{
    var name:String?=null
    var children=ArrayList<Project>()
}
class Project
{
    var name:String?=null
    var size:Int=0
}
