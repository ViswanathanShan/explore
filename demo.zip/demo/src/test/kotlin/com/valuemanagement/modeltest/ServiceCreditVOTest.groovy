/*
 * Copyright (c) 2017.  $Revision:  1.0
 *
 * <AVM_ANALYTICS>
 *  This file contains proprietary information of Cognizant AVM.
 *  Copying or reproduction without prior written approval is prohibited.
 *  All rights reserved
 *  </AVM_ANALYTICS>
 */

package com.valuemanagement.modeltest

class ServiceCreditVOTest extends GroovyTestCase {
    void setUp() {
        super.setUp()
    }

    void tearDown() {
    }

    void testGetBusinessUnit() {
    }

    void testSetBusinessUnit() {
    }

    void testGetAccountName() {
    }

    void testSetAccountName() {
    }

    void testGetProjectName() {
    }

    void testSetProjectName() {
    }

    void testGetCustomerName() {
    }

    void testSetCustomerName() {
    }

    void testGetLob() {
    }

    void testSetLob() {
    }

    void testGetServiceCredit() {
    }

    void testSetServiceCredit() {
    }

    void testGetInternalComments() {
    }

    void testSetInternalComments() {
    }

    void testGetComments() {
    }

    void testSetComments() {
    }

    void testGetStateYear() {
    }

    void testSetStateYear() {
    }

    void testGetEndYear() {
    }

    void testSetEndYear() {
    }

    void testGetPeriodOfContract() {
    }

    void testSetPeriodOfContract() {
    }

    void testGetAttachment() {
    }

    void testSetAttachment() {
    }

    void testGetDueDate() {
    }

    void testSetDueDate() {
    }

    void testGetStatus() {
    }

    void testSetStatus() {
    }

    void testGetCognizantAuthorizers() {
    }

    void testSetCognizantAuthorizers() {
    }

    void testGetCustomerApprovers() {
    }

    void testSetCustomerApprovers() {
    }

    void testEquals() {
    }

    void testHashCode() {
    }

    void testToString() {
    }
}
