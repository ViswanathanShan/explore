package com.example.model

import net.corda.core.serialization.CordaSerializable
import java.util.*

@CordaSerializable
class IOUModel {

    var value:Int=0

    var lender:String?=null

    var borrower:String?=null

    var extraParticioant:String?=null

}
